#include <jni.h>
#include <string>
#include <android/log.h>
#include "llama.h"

#define TAG "iChatOfflineJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_ichat_offline_engine_LlamaBridge_nativeInitModel(
        JNIEnv *env,
        jobject thiz,
        jstring model_path_jstr,
        jint context_size,
        jint threads_count) {

    const char *model_path = env->GetStringUTFChars(model_path_jstr, 0);
    LOGI("Loading model from: %s", model_path);

    llama_backend_init();

    // إعدادات النموذج الأساسية
    llama_model_params model_params = llama_model_default_params();
    model_params.use_mmap = true;
    model_params.use_mlock = false;

    struct llama_model *model = llama_load_model_from_file(model_path, model_params);
    if (!model) {
        LOGE("Failed to load model!");
        env->ReleaseStringUTFChars(model_path_jstr, model_path);
        return 0;
    }

    // إعدادات السياق والمعالجة
    llama_context_params ctx_params = llama_context_default_params();
    
    // تقليص السياق إلى 2048 لمنع التباطؤ أثناء التوليد
    ctx_params.n_ctx = (context_size > 0) ? context_size : 2048;
    
    // حل مشكلة استهلاك المعالج 86% والاختناق الحراري بتحديد 4 خيوط للأداء الأمثل
    ctx_params.n_threads = 4;
    ctx_params.n_threads_batch = 4;
    
    // تحسين الانتباه لتسريع السرعة
    ctx_params.flash_attn = true;

    struct llama_context *ctx = llama_new_context_with_model(model, ctx_params);
    if (!ctx) {
        LOGE("Failed to create llama context!");
        llama_free_model(model);
        env->ReleaseStringUTFChars(model_path_jstr, model_path);
        return 0;
    }

    env->ReleaseStringUTFChars(model_path_jstr, model_path);
    LOGI("Model initialized successfully with Vulkan & optimized threads.");

    return (jlong) ctx;
}

JNIEXPORT void JNICALL
Java_com_ichat_offline_engine_LlamaBridge_nativeFreeModel(
        JNIEnv *env,
        jobject thiz,
        jlong context_ptr) {
    if (context_ptr != 0) {
        struct llama_context *ctx = (struct llama_context *) context_ptr;
        const struct llama_model *model = llama_get_model(ctx);
        llama_free(ctx);
        if (model) {
            llama_free_model(model);
        }
        llama_backend_free();
        LOGI("Model freed successfully.");
    }
}

}
