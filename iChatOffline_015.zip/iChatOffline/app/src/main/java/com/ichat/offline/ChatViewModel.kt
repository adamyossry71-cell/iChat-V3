package com.ichat.offline

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ichat.offline.data.*
import com.ichat.offline.engine.*
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class StreamState(val id: Long, val text: String)

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()

    val chats: StateFlow<List<ChatEntity>> =
        dao.chats().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _current = MutableStateFlow<Long?>(null)
    val currentId: StateFlow<Long?> = _current

    val messages: StateFlow<List<MessageEntity>> = _current
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.messages(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _stream = MutableStateFlow<StreamState?>(null)
    val stream: StateFlow<StreamState?> = _stream
    private val _speed = MutableStateFlow<String?>(null)
    val speed: StateFlow<String?> = _speed
    private val _pending = MutableStateFlow<String?>(null)
    val pendingImage: StateFlow<String?> = _pending
    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice
    fun clearNotice() { _notice.value = null }
    fun clearPending() { _pending.value = null }

    fun canAttach(): Boolean {
        if (!ModelStore.selectedInfo().vision || !ModelStore.isReady(getApplication())) {
            _notice.value = "النموذج المختار دلوقتي مش بيدعم الصور. من القائمة افتح «تحميل نموذج الذكاء الاصطناعي» ونزّل Qwen3-VL-8B (وبعدها اختاره)."
            return false
        }
        return true
    }

    fun attachImage(uri: Uri) {
        if (!ModelStore.selectedInfo().vision || !ModelStore.isReady(getApplication())) {
            _notice.value = "النموذج المختار دلوقتي مش بيدعم الصور. من القائمة افتح «تحميل نموذج الذكاء الاصطناعي» ونزّل Qwen3-VL-8B (وبعدها اختاره)."
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            val bmp = ImageUtil.loadScaled(app, uri)
            if (bmp == null) { _notice.value = "مقدرتش أفتح الصورة دي. جرّب صورة تانية."; return@launch }
            _pending.value = ImageUtil.save(app, bmp).path
        }
    }

    private val _generating = MutableStateFlow(false)
    val generating: StateFlow<Boolean> = _generating

    init { ModelStore.refresh(app) }

    fun open(id: Long) { if (!_generating.value) _current.value = id }
    fun newChat() { if (!_generating.value) _current.value = null }

    fun send(text: String) {
        val img = _pending.value
        val clean = text.trim().ifEmpty {
            if (img != null) "اقرأ كل اللي في الصورة وحل الأسئلة اللي فيها خطوة بخطوة، ولو مفيش أسئلة اشرحلي الصورة." else ""
        }
        if (clean.isEmpty() || _generating.value) return
        if (img != null && !ModelStore.selectedInfo().vision) {
            _notice.value = "النموذج المختار مش بيدعم الصور. اختار Qwen3-VL-8B من شاشة النماذج."
            return
        }
        _pending.value = null
        _generating.value = true
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            var id = _current.value
            if (id == null) {
                id = dao.insertChat(ChatEntity(title = (if (img != null) "🖼️ " else "") + clean.take(40), updatedAt = now))
                _current.value = id
            }
            dao.insertMessage(MessageEntity(chatId = id, role = "user", content = clean, createdAt = now, imagePath = img))
            val aid = dao.insertMessage(MessageEntity(chatId = id, role = "assistant", content = "…", createdAt = now + 1))
            dao.touch(id, now)
            generate(id, aid, now + 1)
        }
    }

    fun regenerate() {
        val chatId = _current.value ?: return
        val last = messages.value.lastOrNull() ?: return
        if (last.role == "user" || _generating.value) return
        _generating.value = true
        viewModelScope.launch {
            dao.deleteMessage(last.id)
            val now = System.currentTimeMillis()
            val aid = dao.insertMessage(MessageEntity(chatId = chatId, role = "assistant", content = "…", createdAt = now))
            generate(chatId, aid, now)
        }
    }

    fun stop() { LlamaBridge.nativeStop() }

    private fun thermalHot(app: Application): Boolean =
        if (Build.VERSION.SDK_INT >= 29) {
            val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.currentThermalStatus >= PowerManager.THERMAL_STATUS_MODERATE
        } else false

    private suspend fun generate(chatId: Long, aid: Long, createdAt: Long) {
        val app = getApplication<Application>()
        val file = ModelStore.modelFile(app)
        try {
            if (!ModelStore.isReady(app)) {
                dao.updateMessage(MessageEntity(aid, chatId, "system",
                    "لسه منزّلتش نموذج الذكاء الاصطناعي. افتح القائمة واختار «تحميل نموذج الذكاء الاصطناعي».", createdAt))
                return
            }
            val history = dao.messagesOnce(chatId).filter { it.id != aid }
            val sys = app.getSharedPreferences("settings", 0).getString("system_prompt", null)
                ?.takeIf { it.isNotBlank() } ?: PromptBuilder.DEFAULT_SYSTEM
            val built = PromptBuilder.build(history, sys)
            val info = ModelStore.selectedInfo()
            val mmproj = ModelStore.mmprojFile(app)?.path
            val threads = app.getSharedPreferences("settings", 0).getInt("threads", 4)
            var hot = false
            var lastThermal = 0L
            val sb = StringBuilder()
            var lastUi = 0L
            var tokens = 0
            var tFirst = 0L
            _speed.value = null
            _stream.value = StreamState(aid, if (built.imagePath != null) "استني بقرا الصورة وبفكر" else "استني بفكر")
            val code = withContext(LlamaEngine.dispatcher) {
                if (!LlamaEngine.ensureLoaded(file.path, mmproj, threads)) -10
                else {
                    var rgb: ByteArray? = null
                    var iw = 0
                    var ih = 0
                    if (built.imagePath != null && LlamaEngine.visionReady) {
                        val bmp = android.graphics.BitmapFactory.decodeFile(built.imagePath)
                        if (bmp != null) { rgb = ImageUtil.toRgb(bmp); iw = bmp.width; ih = bmp.height }
                    }
                    val prompt = if (rgb == null) built.prompt.replace(PromptBuilder.MEDIA_MARKER + "\n", "") else built.prompt
                    LlamaBridge.nativeGenerate(prompt.toByteArray(Charsets.UTF_8), rgb, iw, ih, 1536, if (rgb != null) info.ctx else 4096, object : TokenCallback {
                    override fun onToken(bytes: ByteArray): Boolean {
                        sb.append(String(bytes, Charsets.UTF_8))
                        val now = System.currentTimeMillis()
                        if (tokens == 0) tFirst = now
                        tokens++
                        if (now - lastUi > 250) {
                            lastUi = now
                            _stream.value = StreamState(aid, sb.toString())
                            if (now - lastThermal > 2000) { lastThermal = now; hot = thermalHot(app) }
                            if (tokens > 3 && now > tFirst) _speed.value = "⚡ " + String.format("%.1f", (tokens - 1) * 1000.0 / (now - tFirst)) + " توكن/ث" + (if (hot) " 🌡️ سخن" else "")
                        }
                        return true
                    }
                    })
                }
            }
            val text = sb.toString().trim()
            val msg = when {
                code == -10 -> MessageEntity(aid, chatId, "system",
                    "فشل تحميل النموذج في الذاكرة. اقفل التطبيقات التانية وجرب تاني، أو احذف النموذج ونزّله من جديد.", createdAt)
                code == -6 -> MessageEntity(aid, chatId, "system", "فشلت معالجة الصورة. جرّب صورة أصغر أو أوضح.", createdAt)
                code == -3 -> MessageEntity(aid, chatId, "system", "المحادثة بقت طويلة أوي. ابدأ محادثة جديدة.", createdAt)
                code < 0 && text.isEmpty() -> MessageEntity(aid, chatId, "system", "حصل خطأ أثناء التوليد (كود $code).", createdAt)
                else -> MessageEntity(aid, chatId, "assistant", text.ifEmpty { "(مفيش رد)" }, createdAt)
            }
            dao.updateMessage(msg)
        } finally {
            _stream.value = null
            _generating.value = false
        }
    }

    fun deleteChat(id: Long) {
        viewModelScope.launch {
            if (_current.value == id) _current.value = null
            dao.deleteChat(id)
        }
    }

    fun deleteAll() {
        viewModelScope.launch { _current.value = null; dao.deleteAll() }
    }
}
