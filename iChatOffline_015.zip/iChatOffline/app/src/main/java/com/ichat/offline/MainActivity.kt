package com.ichat.offline

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ichat.offline.engine.PromptBuilder
import com.ichat.offline.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App(vm: ChatViewModel = viewModel()) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("settings", 0) }
    var sysPrompt by remember { mutableStateOf(prefs.getString("system_prompt", null) ?: PromptBuilder.DEFAULT_SYSTEM) }
    var animThink by remember { mutableStateOf(prefs.getBoolean("anim_think", false)) }
    var threads by remember { mutableStateOf(prefs.getInt("threads", 4)) }
    var themeMode by remember { mutableStateOf(prefs.getString("theme", "system") ?: "system") }
    val dark = when (themeMode) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    IChatTheme(dark) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            var screen by rememberSaveable { mutableStateOf("chat") }
            BackHandler(enabled = screen != "chat") { screen = "chat" }
            when (screen) {
                "settings" -> SettingsScreen(
                    themeMode = themeMode,
                    onTheme = { themeMode = it; prefs.edit().putString("theme", it).apply() },
                    prompt = sysPrompt,
                    onPrompt = { sysPrompt = it; prefs.edit().putString("system_prompt", it).apply() },
                    defaultPrompt = PromptBuilder.DEFAULT_SYSTEM,
                    threads = threads,
                    animThink = animThink,
                    onAnimThink = { animThink = it; prefs.edit().putBoolean("anim_think", it).apply() },
                    onThreads = { threads = it; prefs.edit().putInt("threads", it).apply() },
                    onDeleteAll = { vm.deleteAll() },
                    onBack = { screen = "chat" }
                )
                "model" -> ModelScreen(onBack = { screen = "chat" })
                else -> ChatScreen(vm, onSettings = { screen = "settings" }, onModel = { screen = "model" })
            }
        }
    }
}
