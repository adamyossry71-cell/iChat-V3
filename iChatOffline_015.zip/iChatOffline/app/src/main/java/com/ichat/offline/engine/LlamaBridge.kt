package com.ichat.offline.engine

import com.ichat.offline.data.MessageEntity
import kotlinx.coroutines.asCoroutineDispatcher
import java.util.concurrent.Executors

interface TokenCallback {
    /** يرجّع true للاستمرار، false للإيقاف */
    fun onToken(bytes: ByteArray): Boolean
}

object LlamaBridge {
    init { System.loadLibrary("ichat_llama") }
    external fun nativeLoad(path: String, mmproj: String, nCtx: Int, nThreads: Int): Int
    external fun nativeGenerate(prompt: ByteArray, rgb: ByteArray?, w: Int, h: Int, maxTokens: Int, nCtx: Int, cb: TokenCallback): Int
    external fun nativeStop()
    external fun nativeUnload()
}

/** كل عمليات المحرك بتتنفذ على thread واحد عشان الأمان */
object LlamaEngine {
    val dispatcher = Executors.newSingleThreadExecutor { r ->
        Thread(null, {
            // أولوية أعلى للاستدلال عشان الواجهة ما تبطّأش الحساب
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_DISPLAY)
            r.run()
        }, "llama", 8L * 1024 * 1024)
    }.asCoroutineDispatcher()
    private var key: String? = null
    var visionReady = false
        private set

    fun ensureLoaded(path: String, mmproj: String?, threads: Int): Boolean {
        val k = "$path|$mmproj|$threads"
        if (k == key) return true
        val rc = LlamaBridge.nativeLoad(path, mmproj ?: "", 4096, threads)
        if (rc == 1) { key = null; visionReady = false; return false }
        visionReady = (rc == 0 && mmproj != null)
        key = k
        return true
    }

    fun unload() {
        LlamaBridge.nativeUnload()
        key = null
        visionReady = false
    }
}

object PromptBuilder {
    const val DEFAULT_SYSTEM =
        "أنت iChat، مساعد ذكاء اصطناعي يعمل على هاتف المستخدم. اسمك iChat. " +
        "قد يكتب المستخدم بالعامية المصرية أو بأخطاء إملائية، فافهم قصده (مثال: «كود لاله حاسبه» تعني كود آلة حاسبة). " +
        "أجب دائمًا بعربية فصحى مبسطة وواضحة وبجمل قصيرة، ولا تقلّد أي لهجة، وأجب بالإنجليزية إذا كتب المستخدم بالإنجليزية. " +
        "إذا كان الطلب مفهومًا فنفّذه مباشرة وقل افتراضك في سطر واحد، ولا تطرح أسئلة توضيحية إلا عند الضرورة القصوى. " +
        "في البرمجة اكتب كودًا كاملًا يعمل داخل مربع كود ثم شرحًا مختصرًا. " +
        "في المسائل الدراسية اشرح الحل خطوة بخطوة. " +
        "إذا أرسل المستخدم صورة فيها أسئلة امتحان فاقرأ الأسئلة بدقة واكتب النص الذي قرأته أولًا ثم حل كل سؤال خطوة بخطوة، " +
        "وإذا كان جزء من الصورة غير واضح فاذكر ذلك ولا تخمّن. " +
        "إذا لم تكن متأكدًا من شيء فقل ذلك ولا تخترع معلومات."

    const val MEDIA_MARKER = "<__media__>"

    data class Built(val prompt: String, val imagePath: String?)

    /** صيغة ChatML المستخدمة في نماذج Qwen */
    fun build(history: List<MessageEntity>, system: String = DEFAULT_SYSTEM): Built {
        val turns = history.filter { it.role == "user" || it.role == "assistant" }
        val kept = ArrayDeque<MessageEntity>()
        var chars = 0
        for (m in turns.asReversed()) {
            chars += m.content.length
            if (chars > 7000 && kept.isNotEmpty()) break
            kept.addFirst(m)
        }
        val lastImg = kept.lastOrNull { it.role == "user" && it.imagePath != null }
        val sb = StringBuilder()
        sb.append("<|im_start|>system\n").append(system).append("<|im_end|>\n")
        for (m in kept) {
            val content = when {
                lastImg != null && m.id == lastImg.id -> MEDIA_MARKER + "\n" + m.content
                m.imagePath != null -> "[صورة سابقة]\n" + m.content
                else -> m.content
            }
            sb.append("<|im_start|>").append(m.role).append('\n').append(content).append("<|im_end|>\n")
        }
        sb.append("<|im_start|>assistant\n")
        return Built(sb.toString(), lastImg?.imagePath)
    }
}
