package com.ichat.offline

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ichat.offline.data.*
import com.ichat.offline.engine.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class StreamState(val id: Long, val text: String)

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()

    val chats: StateFlow<List<ChatEntity>> =
        dao.chats().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _current = MutableStateFlow<Long?>(null)
    val currentId: StateFlow<Long?> = _current

    val messages: StateFlow<List<MessageEntity>> = _current
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.messages(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _stream = MutableStateFlow<StreamState?>(null)
    val stream: StateFlow<StreamState?> = _stream
    private val _generating = MutableStateFlow(false)
    val generating: StateFlow<Boolean> = _generating

    init { ModelStore.refresh(app) }

    fun open(id: Long) { if (!_generating.value) _current.value = id }
    fun newChat() { if (!_generating.value) _current.value = null }

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isEmpty() || _generating.value) return
        _generating.value = true
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            var id = _current.value
            if (id == null) {
                id = dao.insertChat(ChatEntity(title = clean.take(40), updatedAt = now))
                _current.value = id
            }
            dao.insertMessage(MessageEntity(chatId = id, role = "user", content = clean, createdAt = now))
            val aid = dao.insertMessage(MessageEntity(chatId = id, role = "assistant", content = "…", createdAt = now + 1))
            dao.touch(id, now)
            generate(id, aid, now + 1)
        }
    }

    fun regenerate() {
        val chatId = _current.value ?: return
        val last = messages.value.lastOrNull() ?: return
        if (last.role == "user" || _generating.value) return
        _generating.value = true
        viewModelScope.launch {
            dao.deleteMessage(last.id)
            val now = System.currentTimeMillis()
            val aid = dao.insertMessage(MessageEntity(chatId = chatId, role = "assistant", content = "…", createdAt = now))
            generate(chatId, aid, now)
        }
    }

    fun stop() { LlamaBridge.nativeStop() }

    private suspend fun generate(chatId: Long, aid: Long, createdAt: Long) {
        val app = getApplication<Application>()
        val file = ModelStore.modelFile(app)
        try {
            if (ModelStore.ui.value.status != ModelStore.Status.READY || !file.exists()) {
                dao.updateMessage(MessageEntity(aid, chatId, "system",
                    "لسه منزّلتش نموذج الذكاء الاصطناعي. افتح القائمة واختار «تحميل نموذج الذكاء الاصطناعي».", createdAt))
                return
            }
            val history = dao.messagesOnce(chatId).filter { it.id != aid }
            val prompt = PromptBuilder.build(history)
            val sb = StringBuilder()
            var lastUi = 0L
            _stream.value = StreamState(aid, "جاري تحميل النموذج والتفكير…")
            val code = withContext(LlamaEngine.dispatcher) {
                if (!LlamaEngine.ensureLoaded(file.path)) -10
                else LlamaBridge.nativeGenerate(prompt.toByteArray(Charsets.UTF_8), 1024, object : TokenCallback {
                    override fun onToken(bytes: ByteArray): Boolean {
                        sb.append(String(bytes, Charsets.UTF_8))
                        val now = System.currentTimeMillis()
                        if (now - lastUi > 80) { lastUi = now; _stream.value = StreamState(aid, sb.toString()) }
                        return true
                    }
                })
            }
            val text = sb.toString().trim()
            val msg = when {
                code == -10 -> MessageEntity(aid, chatId, "system",
                    "فشل تحميل النموذج في الذاكرة. اقفل التطبيقات التانية وجرب تاني، أو احذف النموذج ونزّله من جديد.", createdAt)
                code == -3 -> MessageEntity(aid, chatId, "system", "المحادثة بقت طويلة أوي. ابدأ محادثة جديدة.", createdAt)
                code < 0 && text.isEmpty() -> MessageEntity(aid, chatId, "system", "حصل خطأ أثناء التوليد (كود $code).", createdAt)
                else -> MessageEntity(aid, chatId, "assistant", text.ifEmpty { "(مفيش رد)" }, createdAt)
            }
            dao.updateMessage(msg)
        } finally {
            _stream.value = null
            _generating.value = false
        }
    }

    fun deleteChat(id: Long) {
        viewModelScope.launch {
            if (_current.value == id) _current.value = null
            dao.deleteChat(id)
        }
    }

    fun deleteAll() {
        viewModelScope.launch { _current.value = null; dao.deleteAll() }
    }
}
