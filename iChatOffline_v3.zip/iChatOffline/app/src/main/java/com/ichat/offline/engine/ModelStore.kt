package com.ichat.offline.engine

import android.content.Context
import android.os.StatFs
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.coroutineContext

object ModelStore {
    const val NAME = "Qwen2.5-3B-Instruct (Q4_K_M)"
    const val MODEL_URL = "https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/resolve/main/qwen2.5-3b-instruct-q4_k_m.gguf"
    private const val FILE = "qwen2.5-3b-instruct-q4_k_m.gguf"

    enum class Status { ABSENT, DOWNLOADING, READY, FAILED }
    data class Ui(val status: Status = Status.ABSENT, val downloaded: Long = 0, val total: Long = 0, val error: String? = null)

    private val _ui = MutableStateFlow(Ui())
    val ui: StateFlow<Ui> = _ui.asStateFlow()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    private fun dir(ctx: Context) = File(ctx.filesDir, "models").apply { mkdirs() }
    fun modelFile(ctx: Context) = File(dir(ctx), FILE)
    private fun partFile(ctx: Context) = File(dir(ctx), "$FILE.part")

    fun refresh(ctx: Context) {
        if (job?.isActive == true) return
        val f = modelFile(ctx)
        val p = partFile(ctx)
        _ui.value = when {
            f.exists() -> Ui(Status.READY, f.length(), f.length())
            p.exists() -> Ui(Status.ABSENT, p.length(), _ui.value.total)
            else -> Ui()
        }
    }

    fun start(ctx: Context) {
        if (job?.isActive == true) return
        val app = ctx.applicationContext
        job = scope.launch { download(app) }
    }

    fun cancel() { job?.cancel() }

    fun delete(ctx: Context) {
        job?.cancel()
        val app = ctx.applicationContext
        scope.launch {
            job?.join()
            withContext(LlamaEngine.dispatcher) { LlamaEngine.unload() }
            modelFile(app).delete()
            partFile(app).delete()
            _ui.value = Ui()
        }
    }

    private suspend fun download(ctx: Context) {
        val part = partFile(ctx)
        val out = modelFile(ctx)
        var have = if (part.exists()) part.length() else 0L
        _ui.value = Ui(Status.DOWNLOADING, have, _ui.value.total)
        try {
            val conn = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
                connectTimeout = 20000
                readTimeout = 30000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "iChat/0.3")
                if (have > 0) setRequestProperty("Range", "bytes=$have-")
            }
            val code = conn.responseCode
            if (code != 200 && code != 206) throw IOException("رد الخادم: $code")
            val len = conn.contentLengthLong
            if (code == 200) have = 0L
            val total = if (len > 0) have + len else 0L
            val free = StatFs(dir(ctx).path).availableBytes
            if (total > 0 && free < (total - have) + 300L * 1024 * 1024) {
                throw IOException("المساحة مش كفاية. محتاج حوالي ${(total - have + 300L * 1024 * 1024) / (1024 * 1024)} ميجا فاضية.")
            }
            _ui.value = Ui(Status.DOWNLOADING, have, total)
            conn.inputStream.use { input ->
                FileOutputStream(part, code == 206).use { fos ->
                    val buf = ByteArray(64 * 1024)
                    var lastUi = 0L
                    while (true) {
                        coroutineContext.ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        fos.write(buf, 0, n)
                        have += n
                        val now = System.currentTimeMillis()
                        if (now - lastUi > 300) { lastUi = now; _ui.value = Ui(Status.DOWNLOADING, have, total) }
                    }
                }
            }
            if (total > 0 && part.length() != total) throw IOException("الملف اتحمل ناقص، اضغط استكمال.")
            if (!part.renameTo(out)) throw IOException("فشل حفظ الملف.")
            _ui.value = Ui(Status.READY, out.length(), out.length())
        } catch (e: CancellationException) {
            _ui.value = Ui(Status.ABSENT, if (part.exists()) part.length() else 0L, _ui.value.total)
            throw e
        } catch (e: Exception) {
            _ui.value = Ui(Status.FAILED, if (part.exists()) part.length() else 0L, _ui.value.total, e.message ?: "خطأ غير معروف")
        }
    }
}
