package com.ichat.offline.ui

import android.os.StatFs
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ichat.offline.engine.ModelStore

private fun fmt(b: Long): String =
    if (b >= 1L shl 30) String.format("%.2f جيجا", b / (1024.0 * 1024 * 1024)) else String.format("%d ميجا", b / (1024 * 1024))

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModelScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val ui by ModelStore.ui.collectAsStateWithLifecycle()
    val view = LocalView.current
    var confirmDelete by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { ModelStore.refresh(ctx) }
    DisposableEffect(ui.status) {
        view.keepScreenOn = ui.status == ModelStore.Status.DOWNLOADING
        onDispose { view.keepScreenOn = false }
    }
    val free = remember(ui.status, ui.downloaded / (50L * 1024 * 1024)) { StatFs(ctx.filesDir.path).availableBytes }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("نموذج الذكاء الاصطناعي") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") } }
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(ModelStore.NAME, fontWeight = FontWeight.Bold)
                    Text("الحجم: " + if (ui.total > 0) fmt(ui.total) else "حوالي 2 جيجا (هيتحدد بالظبط عند البدء)")
                    Text("المساحة الفاضية على الموبايل: " + fmt(free))
                    Text(
                        "الحالة: " + when (ui.status) {
                            ModelStore.Status.ABSENT -> if (ui.downloaded > 0) "تنزيل متوقف (${fmt(ui.downloaded)})" else "لسه منزّلتش"
                            ModelStore.Status.DOWNLOADING -> "جاري التنزيل..."
                            ModelStore.Status.READY -> "جاهز ✅"
                            ModelStore.Status.FAILED -> "فشل: ${ui.error}"
                        }
                    )
                    if (ui.status == ModelStore.Status.DOWNLOADING || (ui.status != ModelStore.Status.READY && ui.downloaded > 0 && ui.total > 0)) {
                        val p = if (ui.total > 0) ui.downloaded.toFloat() / ui.total else 0f
                        LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth())
                        Text("${(p * 100).toInt()}%  —  ${fmt(ui.downloaded)} من ${fmt(ui.total)}")
                    }
                }
            }
            when (ui.status) {
                ModelStore.Status.DOWNLOADING ->
                    OutlinedButton(onClick = { ModelStore.cancel() }, modifier = Modifier.fillMaxWidth()) { Text("إيقاف مؤقت") }
                ModelStore.Status.READY ->
                    OutlinedButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) { Text("حذف النموذج") }
                else ->
                    Button(onClick = { ModelStore.start(ctx) }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (ui.downloaded > 0) "استكمال التنزيل" else "تحميل النموذج")
                    }
            }
            Text("ملاحظات مهمة", style = MaterialTheme.typography.titleMedium)
            Text("• التنزيل بيستخدم الإنترنت مرة واحدة بس من huggingface.co. بعدها المحادثات النصية بتشتغل من غير إنترنت.")
            Text("• سيب التطبيق مفتوح والشاشة شغالة أثناء التنزيل. لو اتقطع، اضغط «استكمال التنزيل» وهيكمل من حيث وقف.")
            Text("• ده نموذج صغير (3 مليار معامل)، أضعف من ChatGPT وممكن يغلط، خصوصًا في المسائل الصعبة. راجع إجاباته المهمة.")
            Text("• السرعة المتوقعة بضع كلمات في الثانية، والموبايل ممكن يسخن مع الاستخدام الطويل. مفيش وعد بسرعة معينة.")
            Text("• لتغيير النموذج: احذف الحالي ونزّل غيره. اختيارات نماذج تانية هتتضاف في تحديث جاي.")
        }
    }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("حذف النموذج؟") },
        text = { Text("هتحتاج تنزّله تاني عشان الردود تشتغل.") },
        confirmButton = { TextButton(onClick = { ModelStore.delete(ctx); confirmDelete = false }) { Text("حذف") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("إلغاء") } }
    )
}
