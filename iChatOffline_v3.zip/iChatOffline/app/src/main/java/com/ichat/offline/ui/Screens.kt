package com.ichat.offline.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ichat.offline.ChatViewModel
import com.ichat.offline.data.MessageEntity
import kotlinx.coroutines.launch

@Composable
fun Mascot(dp: Dp) {
    Canvas(Modifier.size(dp)) {
        val w = this.size.width
        val blue = Color(0xFF2BA8FF)
        drawCircle(Color(0xFFE8F1FF), radius = w * 0.42f, center = Offset(w / 2, w / 2))
        drawRoundRect(
            Color(0xFF0B1530), topLeft = Offset(w * 0.2f, w * 0.34f),
            size = Size(w * 0.6f, w * 0.3f), cornerRadius = CornerRadius(w * 0.12f)
        )
        val st = Stroke(width = w * 0.035f, cap = StrokeCap.Round)
        drawArc(blue, 200f, 140f, false, Offset(w * 0.3f, w * 0.43f), Size(w * 0.15f, w * 0.12f), style = st)
        drawArc(blue, 200f, 140f, false, Offset(w * 0.55f, w * 0.43f), Size(w * 0.15f, w * 0.12f), style = st)
        drawCircle(blue, radius = w * 0.04f, center = Offset(w * 0.07f, w * 0.5f))
        drawCircle(blue, radius = w * 0.04f, center = Offset(w * 0.93f, w * 0.5f))
    }
}

@Composable
private fun OfflineBadge() {
    Surface(color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f), shape = RoundedCornerShape(8.dp)) {
        Text("Offline", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 1.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatViewModel, onSettings: () -> Unit, onModel: () -> Unit) {
    val messages by vm.messages.collectAsStateWithLifecycle()
    val chats by vm.chats.collectAsStateWithLifecycle()
    val currentId by vm.currentId.collectAsStateWithLifecycle()
    val stream by vm.stream.collectAsStateWithLifecycle()
    val generating by vm.generating.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf<String?>(null) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1) }
    val streamLen = stream?.text?.length ?: 0
    LaunchedEffect(streamLen) { if (streamLen > 0) listState.scrollBy(10000f) }
    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }
    val close: () -> Unit = { scope.launch { drawerState.close() } }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                LazyColumn(contentPadding = PaddingValues(12.dp)) {
                    item {
                        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Mascot(44.dp)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("iChat", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                                OfflineBadge()
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                    item { NavigationDrawerItem(label = { Text("محادثة جديدة") }, icon = { Text("💬") }, selected = false,
                        onClick = { vm.newChat(); close() }) }
                    item { NavigationDrawerItem(label = { Text("تحميل نموذج الذكاء الاصطناعي") }, icon = { Text("⬇️") }, selected = false,
                        onClick = { close(); onModel() }) }
                    item { NavigationDrawerItem(label = { Text("إعدادات التطبيق") }, icon = { Text("⚙️") }, selected = false,
                        onClick = { close(); onSettings() }) }
                    item { NavigationDrawerItem(label = { Text("عن التطبيق") }, icon = { Text("ℹ️") }, selected = false,
                        onClick = { dialog = "about"; close() }) }
                    item { NavigationDrawerItem(label = { Text("مساعدة") }, icon = { Text("❓") }, selected = false,
                        onClick = { dialog = "help"; close() }) }
                    if (chats.isNotEmpty()) {
                        item {
                            HorizontalDivider(Modifier.padding(vertical = 8.dp))
                            Text("المحادثات السابقة", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(8.dp))
                        }
                        items(chats, key = { it.id }) { c ->
                            NavigationDrawerItem(
                                label = { Text(c.title, maxLines = 1) }, selected = c.id == currentId,
                                onClick = { vm.open(c.id); close() },
                                badge = { IconButton(onClick = { vm.deleteChat(c.id) }) { Icon(Icons.Default.Delete, "حذف") } }
                            )
                        }
                    }
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("iChat", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            OfflineBadge()
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                    navigationIcon = { IconButton(onClick = { scope.launch { drawerState.open() } }) { Icon(Icons.Default.Menu, "القائمة") } },
                    actions = { IconButton(onClick = { vm.newChat() }) { Icon(Icons.Default.Add, "محادثة جديدة") } }
                )
            },
            bottomBar = {
                Row(
                    Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(10.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f), placeholder = { Text("اكتب سؤالك هنا...") },
                        maxLines = 5, shape = RoundedCornerShape(26.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    )
                    Spacer(Modifier.width(8.dp))
                    FilledIconButton(
                        onClick = { if (generating) vm.stop() else { vm.send(input); input = "" } },
                        enabled = generating || input.isNotBlank(),
                        modifier = Modifier.size(52.dp)
                    ) { if (generating) Text("■", fontSize = 20.sp) else Icon(Icons.AutoMirrored.Filled.Send, "إرسال") }
                }
            }
        ) { pad ->
            if (messages.isEmpty()) {
                val examples = listOf("اشرحلي الذكاء الاصطناعي ببساطة", "ساعدني أكتب كود بايثون", "حلّلي مسألة رياضة خطوة بخطوة")
                Column(
                    Modifier.padding(pad).fillMaxSize().padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                ) {
                    Mascot(120.dp)
                    Spacer(Modifier.height(8.dp))
                    Text("iChat", fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    OfflineBadge()
                    Spacer(Modifier.height(10.dp))
                    Text("مساعدك الذكي على موبايلك", textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(20.dp))
                    examples.forEach { ex ->
                        Surface(
                            onClick = { vm.send(ex) }, shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        ) { Text(ex, Modifier.padding(14.dp)) }
                    }
                }
            } else {
                LazyColumn(
                    Modifier.padding(pad).fillMaxSize(), state = listState,
                    contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    itemsIndexed(messages, key = { _, m -> m.id }) { i, m ->
                        MessageBubble(
                            m, stream?.takeIf { it.id == m.id }?.text,
                            isLast = i == messages.lastIndex && !generating,
                            onRegenerate = { vm.regenerate() }
                        )
                    }
                }
            }
        }
    }

    dialog?.let { key ->
        val (t, body) = when (key) {
            "about" -> "عن iChat" to "الإصدار 0.3: واجهة المحادثة، وحفظ السجل على الموبايل، وتشغيل نموذج Qwen2.5 3B محليًا بعد تنزيله. فهم الصور لسه مش موجود (المرحلة 3)."
            else -> "مساعدة" to "أول مرة: افتح القائمة واختار «تحميل نموذج الذكاء الاصطناعي» ونزّل النموذج. بعدها اكتب سؤالك. كل المحادثات محفوظة على موبايلك بس."
        }
        AlertDialog(
            onDismissRequest = { dialog = null }, title = { Text(t) }, text = { Text(body) },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("تمام") } }
        )
    }
}

@Composable
private fun MessageBubble(m: MessageEntity, streamText: String?, isLast: Boolean, onRegenerate: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    val cs = MaterialTheme.colorScheme
    when (m.role) {
        "user" -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
            Surface(color = cs.primaryContainer, shape = RoundedCornerShape(18.dp), modifier = Modifier.widthIn(max = 300.dp)) {
                Text(m.content, Modifier.padding(horizontal = 14.dp, vertical = 10.dp), color = cs.onPrimaryContainer)
            }
        }
        "system" -> Surface(color = cs.surfaceVariant, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text(m.content, color = cs.onSurfaceVariant, fontSize = 14.sp)
                if (isLast) TextButton(onClick = onRegenerate) { Text("إعادة المحاولة") }
            }
        }
        else -> Surface(
            color = cs.surfaceVariant, shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, cs.outlineVariant), modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(12.dp)) {
                Markdown(streamText ?: m.content)
                if (streamText == null) Row {
                    TextButton(onClick = { clipboard.setText(AnnotatedString(m.content)) }) { Text("نسخ") }
                    if (isLast) TextButton(onClick = onRegenerate) { Text("إعادة") }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(themeMode: String, onTheme: (String) -> Unit, onDeleteAll: () -> Unit, onBack: () -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("الإعدادات") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") } }
        )
    }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("المظهر", style = MaterialTheme.typography.titleMedium)
            listOf("system" to "حسب النظام", "light" to "فاتح", "dark" to "داكن").forEach { (k, label) ->
                Row(
                    Modifier.fillMaxWidth().clickable { onTheme(k) },
                    verticalAlignment = Alignment.CenterVertically
                ) { RadioButton(selected = themeMode == k, onClick = { onTheme(k) }); Text(label) }
            }
            HorizontalDivider()
            Text("الخصوصية", style = MaterialTheme.typography.titleMedium)
            Text("كل المحادثات تُحفظ على هاتفك فقط، ولا يرسل التطبيق أي شيء لأي خادم. الإنترنت سيُستخدم لاحقًا فقط لتنزيل النموذج بموافقتك.")
            OutlinedButton(onClick = { confirm = true }) { Text("حذف كل المحادثات") }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("حذف كل المحادثات؟") },
        text = { Text("لا يمكن التراجع عن هذا الإجراء.") },
        confirmButton = { TextButton(onClick = { onDeleteAll(); confirm = false }) { Text("حذف") } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("إلغاء") } }
    )
}
