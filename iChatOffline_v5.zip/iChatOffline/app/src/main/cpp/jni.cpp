#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <algorithm>
#include <string>
#include <vector>
#include "llama.h"

#define TAG "iChatLlama"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static llama_model* g_model = nullptr;
static const llama_vocab* g_vocab = nullptr;
static int g_n_ctx = 4096;
static int g_threads = 6;
static std::atomic<bool> g_stop{false};
static bool g_backend = false;

// يرجّع طول أكبر جزء من النص بيكون UTF-8 كامل (عشان ما نبعتش حرف مقطوع)
static size_t utf8_complete_prefix(const std::string& s) {
    size_t n = s.size();
    if (n == 0) return 0;
    size_t i = n;
    int back = 0;
    while (i > 0 && back < 4) {
        i--; back++;
        unsigned char c = (unsigned char) s[i];
        if ((c & 0xC0) != 0x80) {
            int need = (c < 0x80) ? 1 : ((c & 0xE0) == 0xC0) ? 2 : ((c & 0xF0) == 0xE0) ? 3 : ((c & 0xF8) == 0xF0) ? 4 : 1;
            if (need > back) return i;
            return n;
        }
    }
    return n;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_ichat_offline_engine_LlamaBridge_nativeLoad(JNIEnv* env, jobject, jstring jpath, jint nCtx, jint nThreads) {
    if (!g_backend) { llama_backend_init(); g_backend = true; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; g_vocab = nullptr; }
    const char* path = env->GetStringUTFChars(jpath, nullptr);
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    mp.use_mmap = true;
    g_model = llama_model_load_from_file(path, mp);
    env->ReleaseStringUTFChars(jpath, path);
    if (!g_model) { LOGE("model load failed"); return JNI_FALSE; }
    g_vocab = llama_model_get_vocab(g_model);
    g_n_ctx = nCtx;
    g_threads = nThreads;
    return JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_ichat_offline_engine_LlamaBridge_nativeUnload(JNIEnv*, jobject) {
    if (g_model) { llama_model_free(g_model); g_model = nullptr; g_vocab = nullptr; }
}

extern "C" JNIEXPORT void JNICALL
Java_com_ichat_offline_engine_LlamaBridge_nativeStop(JNIEnv*, jobject) {
    g_stop = true;
}

// أكواد الرجوع: 0 تمام، -1 مفيش نموذج، -2 فشل التقسيم، -3 المحادثة طويلة، -4 فشل فك، -5 فشل إنشاء السياق
extern "C" JNIEXPORT jint JNICALL
Java_com_ichat_offline_engine_LlamaBridge_nativeGenerate(JNIEnv* env, jobject, jbyteArray jprompt, jint maxTokens, jobject cb) {
    if (!g_model) return -1;
    g_stop = false;

    jclass cls = env->GetObjectClass(cb);
    jmethodID mid = env->GetMethodID(cls, "onToken", "([B)Z");
    if (!mid) return -5;

    jsize plen = env->GetArrayLength(jprompt);
    std::string prompt((size_t) plen, '\0');
    env->GetByteArrayRegion(jprompt, 0, plen, reinterpret_cast<jbyte*>(&prompt[0]));

    int n = -llama_tokenize(g_vocab, prompt.c_str(), (int) prompt.size(), nullptr, 0, false, true);
    if (n <= 0) return -2;
    std::vector<llama_token> toks(n);
    if (llama_tokenize(g_vocab, prompt.c_str(), (int) prompt.size(), toks.data(), n, false, true) < 0) return -2;
    if (n + 16 > g_n_ctx) return -3;
    int maxNew = std::min((int) maxTokens, g_n_ctx - n - 8);

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = g_n_ctx;
    cp.n_batch = 512;
    cp.n_threads = g_threads;
    cp.n_threads_batch = g_threads;
    llama_context* ctx = llama_init_from_model(g_model, cp);
    if (!ctx) return -5;

    llama_sampler* smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(0.5f));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    int rc = 0;
    for (int i = 0; i < n && !g_stop; i += (int) cp.n_batch) {
        int c = std::min((int) cp.n_batch, n - i);
        llama_batch b = llama_batch_get_one(toks.data() + i, c);
        if (llama_decode(ctx, b) != 0) { rc = -4; break; }
    }

    std::string pending;
    char buf[256];
    for (int step = 0; rc == 0 && !g_stop && step < maxNew; step++) {
        llama_token id = llama_sampler_sample(smpl, ctx, -1);
        if (llama_vocab_is_eog(g_vocab, id)) break;
        int len = llama_token_to_piece(g_vocab, id, buf, sizeof(buf), 0, true);
        if (len > 0) pending.append(buf, (size_t) len);
        size_t k = utf8_complete_prefix(pending);
        if (k > 0) {
            jbyteArray arr = env->NewByteArray((jsize) k);
            env->SetByteArrayRegion(arr, 0, (jsize) k, reinterpret_cast<const jbyte*>(pending.data()));
            pending.erase(0, k);
            jboolean cont = env->CallBooleanMethod(cb, mid, arr);
            env->DeleteLocalRef(arr);
            if (env->ExceptionCheck()) { env->ExceptionClear(); break; }
            if (!cont) break;
        }
        llama_batch b = llama_batch_get_one(&id, 1);
        if (llama_decode(ctx, b) != 0) { rc = -4; break; }
    }

    llama_sampler_free(smpl);
    llama_free(ctx);
    return rc;
}
