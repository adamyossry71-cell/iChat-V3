package com.ichat.offline.engine

import kotlinx.coroutines.asCoroutineDispatcher
import java.util.concurrent.Executors

interface TokenCallback {
    /** يرجّع true للاستمرار، false للإيقاف */
    fun onToken(bytes: ByteArray): Boolean
}

object LlamaBridge {
    init { System.loadLibrary("ichat_llama") }
    external fun nativeLoad(path: String, nCtx: Int, nThreads: Int): Boolean
    external fun nativeGenerate(prompt: ByteArray, maxTokens: Int, cb: TokenCallback): Int
    external fun nativeStop()
    external fun nativeUnload()
}

/** كل عمليات المحرك بتتنفذ على thread واحد عشان الأمان */
object LlamaEngine {
    val dispatcher = Executors.newSingleThreadExecutor { r -> Thread(null, r, "llama", 8L * 1024 * 1024) }.asCoroutineDispatcher()
    private var loadedPath: String? = null

    fun ensureLoaded(path: String): Boolean {
        if (loadedPath == path) return true
        val ok = LlamaBridge.nativeLoad(path, 4096, 6)
        loadedPath = if (ok) path else null
        return ok
    }

    fun unload() {
        LlamaBridge.nativeUnload()
        loadedPath = null
    }
}

object PromptBuilder {
    private const val SYSTEM =
        "أنت iChat، مساعد ذكاء اصطناعي بيتكلم عربي بطلاقة وبيفهم الإنجليزي. " +
        "المستخدم غالبًا بيكتب بالعامية المصرية وبأخطاء إملائية، فافهم قصده بدل ما تستغرب. " +
        "مثال: «اعملي كود لاله حاسبه» معناها «اكتبلي كود آلة حاسبة». " +
        "لو الطلب ممكن يتفهم، نفّذه على طول بأقرب معنى منطقي وقول افتراضك في سطر واحد، " +
        "ولا تسأل أسئلة توضيحية إلا لو مفيش أي طريقة تفهم بيها الطلب. " +
        "رد بنفس لغة المستخدم، وبالعامية المصرية البسيطة لو كتب بيها. " +
        "في البرمجة اكتب كود كامل شغال داخل مربع كود، وبعده شرح مختصر. " +
        "في المسائل الدراسية اشرح الحل خطوة بخطوة. " +
        "لو مش متأكد من حاجة قول إنك مش متأكد، وما تخترعش معلومات."

    /** صيغة ChatML المستخدمة في نماذج Qwen */
    fun build(history: List<com.ichat.offline.data.MessageEntity>): String {
        val turns = history.filter { it.role == "user" || it.role == "assistant" }
        val kept = ArrayDeque<com.ichat.offline.data.MessageEntity>()
        var chars = 0
        for (m in turns.asReversed()) {
            chars += m.content.length
            if (chars > 7000 && kept.isNotEmpty()) break
            kept.addFirst(m)
        }
        val sb = StringBuilder()
        sb.append("<|im_start|>system\n").append(SYSTEM).append("<|im_end|>\n")
        for (m in kept) sb.append("<|im_start|>").append(m.role).append('\n').append(m.content).append("<|im_end|>\n")
        sb.append("<|im_start|>assistant\n")
        return sb.toString()
    }
}
