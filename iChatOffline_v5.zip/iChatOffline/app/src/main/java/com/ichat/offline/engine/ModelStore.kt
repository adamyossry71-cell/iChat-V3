package com.ichat.offline.engine

import android.content.Context
import android.os.StatFs
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.coroutineContext

object ModelStore {
    data class ModelInfo(
        val id: String, val name: String, val note: String,
        val url: String, val file: String, val approxBytes: Long
    )

    val models = listOf(
        ModelInfo(
            "q3b", "Qwen2.5-3B (سريع)",
            "أسرع وأخف، لكن فهمه للعامية والمسائل الصعبة أضعف.",
            "https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/resolve/main/qwen2.5-3b-instruct-q4_k_m.gguf",
            "qwen2.5-3b-instruct-q4_k_m.gguf", 2_100_000_000L
        ),
        ModelInfo(
            "q7b", "Qwen2.5-7B (أذكى وأبطأ)",
            "أفهم وأدق غالبًا، لكن أبطأ تقريبًا للضعف وبيسخّن أكتر. محتاج حوالي 5 جيجا مساحة ورام.",
            "https://huggingface.co/bartowski/Qwen2.5-7B-Instruct-GGUF/resolve/main/Qwen2.5-7B-Instruct-Q4_K_M.gguf",
            "Qwen2.5-7B-Instruct-Q4_K_M.gguf", 4_680_000_000L
        )
    )

    enum class Status { ABSENT, DOWNLOADING, READY, FAILED }
    data class Ui(val status: Status = Status.ABSENT, val downloaded: Long = 0, val total: Long = 0, val error: String? = null)

    private val _ui = MutableStateFlow<Map<String, Ui>>(emptyMap())
    val ui: StateFlow<Map<String, Ui>> = _ui.asStateFlow()
    private val _selected = MutableStateFlow("q3b")
    val selected: StateFlow<String> = _selected.asStateFlow()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var jobId: String? = null

    private fun dir(ctx: Context) = File(ctx.filesDir, "models").apply { mkdirs() }
    private fun info(id: String) = models.first { it.id == id }
    fun modelFile(ctx: Context, id: String = _selected.value) = File(dir(ctx), info(id).file)
    private fun partFile(ctx: Context, id: String) = File(dir(ctx), info(id).file + ".part")
    private fun setUi(id: String, u: Ui) { _ui.value = _ui.value + (id to u) }

    fun refresh(ctx: Context) {
        val prefs = ctx.getSharedPreferences("settings", 0)
        val saved = prefs.getString("model", "q3b") ?: "q3b"
        _selected.value = if (models.any { it.id == saved }) saved else "q3b"
        for (m in models) {
            if (job?.isActive == true && jobId == m.id) continue
            val f = modelFile(ctx, m.id)
            val p = partFile(ctx, m.id)
            setUi(m.id, when {
                f.exists() -> Ui(Status.READY, f.length(), f.length())
                p.exists() -> Ui(Status.ABSENT, p.length(), m.approxBytes)
                else -> Ui(total = m.approxBytes)
            })
        }
    }

    fun select(ctx: Context, id: String) {
        ctx.getSharedPreferences("settings", 0).edit().putString("model", id).apply()
        _selected.value = id
    }

    fun start(ctx: Context, id: String) {
        if (job?.isActive == true) return
        val app = ctx.applicationContext
        jobId = id
        job = scope.launch { download(app, info(id)) }
    }

    fun cancel() { job?.cancel() }

    fun delete(ctx: Context, id: String) {
        val app = ctx.applicationContext
        if (job?.isActive == true && jobId == id) job?.cancel()
        scope.launch {
            if (jobId == id) job?.join()
            withContext(LlamaEngine.dispatcher) { LlamaEngine.unload() }
            modelFile(app, id).delete()
            partFile(app, id).delete()
            setUi(id, Ui(total = info(id).approxBytes))
        }
    }

    private suspend fun download(ctx: Context, m: ModelInfo) {
        val part = partFile(ctx, m.id)
        val out = modelFile(ctx, m.id)
        var have = if (part.exists()) part.length() else 0L
        setUi(m.id, Ui(Status.DOWNLOADING, have, m.approxBytes))
        try {
            val conn = (URL(m.url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 20000
                readTimeout = 30000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "iChat/0.5")
                if (have > 0) setRequestProperty("Range", "bytes=$have-")
            }
            val code = conn.responseCode
            if (code != 200 && code != 206) throw IOException("رد الخادم: $code")
            val len = conn.contentLengthLong
            if (code == 200) have = 0L
            val total = if (len > 0) have + len else 0L
            val need = (if (total > 0) total - have else m.approxBytes - have) + 300L * 1024 * 1024
            if (StatFs(dir(ctx).path).availableBytes < need) {
                throw IOException("المساحة مش كفاية. محتاج حوالي ${need / (1024 * 1024)} ميجا فاضية.")
            }
            setUi(m.id, Ui(Status.DOWNLOADING, have, if (total > 0) total else m.approxBytes))
            conn.inputStream.use { input ->
                FileOutputStream(part, code == 206).use { fos ->
                    val buf = ByteArray(64 * 1024)
                    var lastUi = 0L
                    while (true) {
                        coroutineContext.ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        fos.write(buf, 0, n)
                        have += n
                        val now = System.currentTimeMillis()
                        if (now - lastUi > 300) {
                            lastUi = now
                            setUi(m.id, Ui(Status.DOWNLOADING, have, if (total > 0) total else m.approxBytes))
                        }
                    }
                }
            }
            if (total > 0 && part.length() != total) throw IOException("الملف اتحمل ناقص، اضغط استكمال.")
            if (!part.renameTo(out)) throw IOException("فشل حفظ الملف.")
            setUi(m.id, Ui(Status.READY, out.length(), out.length()))
            select(ctx, m.id)
        } catch (e: CancellationException) {
            setUi(m.id, Ui(Status.ABSENT, if (part.exists()) part.length() else 0L, m.approxBytes))
            throw e
        } catch (e: Exception) {
            setUi(m.id, Ui(Status.FAILED, if (part.exists()) part.length() else 0L, m.approxBytes, e.message ?: "خطأ غير معروف"))
        }
    }
}
