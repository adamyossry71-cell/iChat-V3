package com.ichat.offline.ui

import android.os.StatFs
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ichat.offline.engine.ModelStore

private fun fmt(b: Long): String =
    if (b >= 1L shl 30) String.format("%.2f جيجا", b / (1024.0 * 1024 * 1024)) else String.format("%d ميجا", b / (1024 * 1024))

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModelScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val all by ModelStore.ui.collectAsStateWithLifecycle()
    val selected by ModelStore.selected.collectAsStateWithLifecycle()
    val view = LocalView.current
    var confirmDelete by remember { mutableStateOf<String?>(null) }
    val anyDownloading = all.values.any { it.status == ModelStore.Status.DOWNLOADING }
    LaunchedEffect(Unit) { ModelStore.refresh(ctx) }
    DisposableEffect(anyDownloading) {
        view.keepScreenOn = anyDownloading
        onDispose { view.keepScreenOn = false }
    }
    val free = StatFs(ctx.filesDir.path).availableBytes

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("نماذج الذكاء الاصطناعي") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") } }
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("المساحة الفاضية على الموبايل: " + fmt(free))
            for (m in ModelStore.models) {
                val ui = all[m.id] ?: ModelStore.Ui(total = m.approxBytes)
                val ready = ui.status == ModelStore.Status.READY
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(m.name, fontWeight = FontWeight.Bold)
                        Text(m.note)
                        Text("الحجم: " + fmt(if (ui.total > 0) ui.total else m.approxBytes))
                        Text(
                            "الحالة: " + when (ui.status) {
                                ModelStore.Status.ABSENT -> if (ui.downloaded > 0) "تنزيل متوقف (${fmt(ui.downloaded)})" else "لسه منزّلتش"
                                ModelStore.Status.DOWNLOADING -> "جاري التنزيل..."
                                ModelStore.Status.READY -> if (selected == m.id) "جاهز ✅ (المستخدم حاليًا)" else "جاهز ✅"
                                ModelStore.Status.FAILED -> "فشل: ${ui.error}"
                            }
                        )
                        if (!ready && ui.downloaded > 0) {
                            val p = if (ui.total > 0) ui.downloaded.toFloat() / ui.total else 0f
                            LinearProgressIndicator(progress = { p.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                            Text("${(p * 100).toInt()}%  —  ${fmt(ui.downloaded)} من ${fmt(ui.total)}")
                        }
                        when {
                            ui.status == ModelStore.Status.DOWNLOADING ->
                                OutlinedButton(onClick = { ModelStore.cancel() }, modifier = Modifier.fillMaxWidth()) { Text("إيقاف مؤقت") }
                            ready -> {
                                if (selected != m.id) Button(onClick = { ModelStore.select(ctx, m.id) }, modifier = Modifier.fillMaxWidth()) { Text("استخدام هذا النموذج") }
                                OutlinedButton(onClick = { confirmDelete = m.id }, modifier = Modifier.fillMaxWidth()) { Text("حذف النموذج") }
                            }
                            else -> Button(
                                onClick = { ModelStore.start(ctx, m.id) }, enabled = !anyDownloading,
                                modifier = Modifier.fillMaxWidth()
                            ) { Text(if (ui.downloaded > 0) "استكمال التنزيل" else "تحميل النموذج") }
                        }
                    }
                }
            }
            Text("ملاحظات مهمة", style = MaterialTheme.typography.titleMedium)
            Text("• التنزيل بيستخدم الإنترنت مرة واحدة لكل نموذج من huggingface.co. بعدها المحادثات النصية بتشتغل من غير إنترنت.")
            Text("• سيب التطبيق مفتوح والشاشة شغالة أثناء التنزيل. لو اتقطع اضغط «استكمال التنزيل».")
            Text("• النماذج الصغيرة أضعف من ChatGPT وممكن تغلط. راجع إجاباتك المهمة.")
            Text("• بعد تغيير النموذج، أول رسالة بتاخد وقت أطول لأن النموذج بيتحمّل في الذاكرة.")
        }
    }
    confirmDelete?.let { id ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("حذف النموذج؟") },
            text = { Text("هتحتاج تنزّله تاني عشان تستخدمه.") },
            confirmButton = { TextButton(onClick = { ModelStore.delete(ctx, id); confirmDelete = null }) { Text("حذف") } },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("إلغاء") } }
        )
    }
}
