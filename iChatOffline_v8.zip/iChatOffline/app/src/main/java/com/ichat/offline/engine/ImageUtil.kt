package com.ichat.offline.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import java.io.File
import java.io.FileOutputStream

object ImageUtil {
    private const val MAX_SIDE = 1024

    fun loadScaled(ctx: Context, uri: Uri): Bitmap? = try {
        if (Build.VERSION.SDK_INT >= 28) {
            val src = ImageDecoder.createSource(ctx.contentResolver, uri)
            ImageDecoder.decodeBitmap(src) { dec, info, _ ->
                dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val w = info.size.width
                val h = info.size.height
                val s = maxOf(w, h)
                if (s > MAX_SIDE) dec.setTargetSize(maxOf(1, w * MAX_SIDE / s), maxOf(1, h * MAX_SIDE / s))
            }
        } else {
            val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        }
    } catch (e: Exception) { null }

    fun save(ctx: Context, bmp: Bitmap): File {
        val dir = File(ctx.filesDir, "images").apply { mkdirs() }
        val f = File(dir, "img_${System.currentTimeMillis()}.jpg")
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        return f
    }

    /** يرجّع RGB خام (3 بايت لكل بكسل) */
    fun toRgb(bmp: Bitmap): ByteArray {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val out = ByteArray(w * h * 3)
        for (i in px.indices) {
            val p = px[i]
            out[3 * i] = (p shr 16).toByte()
            out[3 * i + 1] = (p shr 8).toByte()
            out[3 * i + 2] = p.toByte()
        }
        return out
    }
}
