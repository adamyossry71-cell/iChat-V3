package com.ichat.offline.engine

import com.ichat.offline.data.MessageEntity
import kotlinx.coroutines.asCoroutineDispatcher
import java.util.concurrent.Executors

interface TokenCallback {
    /** يرجّع true للاستمرار، false للإيقاف */
    fun onToken(bytes: ByteArray): Boolean
}

object LlamaBridge {
    init { System.loadLibrary("ichat_llama") }
    external fun nativeLoad(path: String, mmproj: String, nCtx: Int, nThreads: Int): Int
    external fun nativeGenerate(prompt: ByteArray, rgb: ByteArray?, w: Int, h: Int, maxTokens: Int, cb: TokenCallback): Int
    external fun nativeStop()
    external fun nativeUnload()
}

/** كل عمليات المحرك بتتنفذ على thread واحد عشان الأمان */
object LlamaEngine {
    val dispatcher = Executors.newSingleThreadExecutor { r -> Thread(null, r, "llama", 8L * 1024 * 1024) }.asCoroutineDispatcher()
    private var key: String? = null
    var visionReady = false
        private set

    fun ensureLoaded(path: String, mmproj: String?, nCtx: Int): Boolean {
        val k = "$path|$mmproj|$nCtx"
        if (k == key) return true
        val rc = LlamaBridge.nativeLoad(path, mmproj ?: "", nCtx, 6)
        if (rc == 1) { key = null; visionReady = false; return false }
        visionReady = (rc == 0 && mmproj != null)
        key = k
        return true
    }

    fun unload() {
        LlamaBridge.nativeUnload()
        key = null
        visionReady = false
    }
}

object PromptBuilder {
    private const val SYSTEM =
        "أنت iChat، مساعد ذكاء اصطناعي بيتكلم عربي بطلاقة وبيفهم الإنجليزي. " +
        "المستخدم غالبًا بيكتب بالعامية المصرية وبأخطاء إملائية، فافهم قصده بدل ما تستغرب. " +
        "مثال: «اعملي كود لاله حاسبه» معناها «اكتبلي كود آلة حاسبة». " +
        "لو الطلب ممكن يتفهم، نفّذه على طول بأقرب معنى منطقي وقول افتراضك في سطر واحد، " +
        "ولا تسأل أسئلة توضيحية إلا لو مفيش أي طريقة تفهم بيها الطلب. " +
        "رد بنفس لغة المستخدم، وبالعامية المصرية البسيطة لو كتب بيها. " +
        "في البرمجة اكتب كود كامل شغال داخل مربع كود، وبعده شرح مختصر. " +
        "في المسائل الدراسية اشرح الحل خطوة بخطوة. " +
        "لو المستخدم بعتلك صورة فيها أسئلة امتحان: اقرأ الأسئلة بدقة واكتب النص اللي قريته الأول، " +
        "وبعدين حل كل سؤال خطوة بخطوة، ولو جزء من الصورة مش واضح قول كده بدل ما تخمّن. " +
        "لو مش متأكد من حاجة قول إنك مش متأكد، وما تخترعش معلومات."

    const val MEDIA_MARKER = "<__media__>"

    data class Built(val prompt: String, val imagePath: String?)

    /** صيغة ChatML المستخدمة في نماذج Qwen */
    fun build(history: List<MessageEntity>): Built {
        val turns = history.filter { it.role == "user" || it.role == "assistant" }
        val kept = ArrayDeque<MessageEntity>()
        var chars = 0
        for (m in turns.asReversed()) {
            chars += m.content.length
            if (chars > 7000 && kept.isNotEmpty()) break
            kept.addFirst(m)
        }
        val lastImg = kept.lastOrNull { it.role == "user" && it.imagePath != null }
        val sb = StringBuilder()
        sb.append("<|im_start|>system\n").append(SYSTEM).append("<|im_end|>\n")
        for (m in kept) {
            val content = when {
                lastImg != null && m.id == lastImg.id -> MEDIA_MARKER + "\n" + m.content
                m.imagePath != null -> "[صورة سابقة]\n" + m.content
                else -> m.content
            }
            sb.append("<|im_start|>").append(m.role).append('\n').append(content).append("<|im_end|>\n")
        }
        sb.append("<|im_start|>assistant\n")
        return Built(sb.toString(), lastImg?.imagePath)
    }
}
