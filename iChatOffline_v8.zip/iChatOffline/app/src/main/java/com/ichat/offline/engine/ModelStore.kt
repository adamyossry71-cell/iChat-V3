package com.ichat.offline.engine

import android.content.Context
import android.os.StatFs
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.coroutineContext

object ModelStore {
    data class ModelFile(val url: String, val name: String, val approx: Long)
    data class ModelInfo(
        val id: String, val name: String, val note: String,
        val files: List<ModelFile>, val ctx: Int, val vision: Boolean
    ) { val approxTotal: Long get() = files.sumOf { it.approx } }

    val models = listOf(
        ModelInfo(
            "q3b", "Qwen2.5-3B (سريع)",
            "أسرع وأخف، لكن فهمه للعامية والمسائل الصعبة أضعف. نص فقط.",
            listOf(ModelFile(
                "https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/resolve/main/qwen2.5-3b-instruct-q4_k_m.gguf",
                "qwen2.5-3b-instruct-q4_k_m.gguf", 2_100_000_000L)),
            4096, false
        ),
        ModelInfo(
            "q7b", "Qwen2.5-7B (أذكى وأبطأ)",
            "أفهم وأدق من الـ 3B، لكن أبطأ تقريبًا للضعف وبيسخّن أكتر. نص فقط.",
            listOf(ModelFile(
                "https://huggingface.co/bartowski/Qwen2.5-7B-Instruct-GGUF/resolve/main/Qwen2.5-7B-Instruct-Q4_K_M.gguf",
                "Qwen2.5-7B-Instruct-Q4_K_M.gguf", 4_680_000_000L)),
            4096, false
        ),
        ModelInfo(
            "q3vl8b", "Qwen3-VL-8B (الأقوى + فهم الصور) ⭐",
            "الأقوى المتاح هنا: بيفهم النص والصور مع بعض (امتحانات، لقطات شاشة، أكواد). أبطأ، وتحليل الصورة بياخد وقت قبل أول كلمة، والموبايل بيسخّن. محتاج حوالي 6 جيجا مساحة.",
            listOf(
                ModelFile(
                    "https://huggingface.co/Qwen/Qwen3-VL-8B-Instruct-GGUF/resolve/main/Qwen3VL-8B-Instruct-Q4_K_M.gguf",
                    "Qwen3VL-8B-Instruct-Q4_K_M.gguf", 5_030_000_000L),
                ModelFile(
                    "https://huggingface.co/Qwen/Qwen3-VL-8B-Instruct-GGUF/resolve/main/mmproj-Qwen3VL-8B-Instruct-Q8_0.gguf",
                    "mmproj-Qwen3VL-8B-Instruct-Q8_0.gguf", 752_000_000L)
            ),
            8192, true
        )
    )

    enum class Status { ABSENT, DOWNLOADING, READY, FAILED }
    data class Ui(val status: Status = Status.ABSENT, val downloaded: Long = 0, val total: Long = 0, val error: String? = null)

    private val _ui = MutableStateFlow<Map<String, Ui>>(emptyMap())
    val ui: StateFlow<Map<String, Ui>> = _ui.asStateFlow()
    private val _selected = MutableStateFlow("q3b")
    val selected: StateFlow<String> = _selected.asStateFlow()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var jobId: String? = null

    private fun dir(ctx: Context) = File(ctx.filesDir, "models").apply { mkdirs() }
    private fun info(id: String) = models.first { it.id == id }
    fun selectedInfo(): ModelInfo = info(_selected.value)
    fun modelFile(ctx: Context, id: String = _selected.value) = File(dir(ctx), info(id).files[0].name)
    /** ملف الصور (mmproj) لو النموذج بيدعم الصور وموجود، وإلا null */
    fun mmprojFile(ctx: Context, id: String = _selected.value): File? {
        val f = info(id).files.getOrNull(1) ?: return null
        return File(dir(ctx), f.name).takeIf { it.exists() }
    }
    fun isReady(ctx: Context, id: String = _selected.value) = info(id).files.all { File(dir(ctx), it.name).exists() }
    private fun setUi(id: String, u: Ui) { _ui.value = _ui.value + (id to u) }

    fun refresh(ctx: Context) {
        val prefs = ctx.getSharedPreferences("settings", 0)
        val saved = prefs.getString("model", "q3b") ?: "q3b"
        _selected.value = if (models.any { it.id == saved }) saved else "q3b"
        for (m in models) {
            if (job?.isActive == true && jobId == m.id) continue
            var have = 0L
            for (f in m.files) {
                val o = File(dir(ctx), f.name)
                val p = File(dir(ctx), f.name + ".part")
                have += if (o.exists()) o.length() else if (p.exists()) p.length() else 0L
            }
            setUi(m.id, when {
                isReady(ctx, m.id) -> Ui(Status.READY, have, have)
                else -> Ui(Status.ABSENT, have, m.approxTotal)
            })
        }
    }

    fun select(ctx: Context, id: String) {
        ctx.getSharedPreferences("settings", 0).edit().putString("model", id).apply()
        _selected.value = id
    }

    fun start(ctx: Context, id: String) {
        if (job?.isActive == true) return
        val app = ctx.applicationContext
        jobId = id
        job = scope.launch { download(app, info(id)) }
    }

    fun cancel() { job?.cancel() }

    fun delete(ctx: Context, id: String) {
        val app = ctx.applicationContext
        if (job?.isActive == true && jobId == id) job?.cancel()
        scope.launch {
            if (jobId == id) job?.join()
            withContext(LlamaEngine.dispatcher) { LlamaEngine.unload() }
            for (f in info(id).files) {
                File(dir(app), f.name).delete()
                File(dir(app), f.name + ".part").delete()
            }
            setUi(id, Ui(total = info(id).approxTotal))
        }
    }

    private suspend fun download(ctx: Context, m: ModelInfo) {
        var done = 0L
        setUi(m.id, Ui(Status.DOWNLOADING, 0, m.approxTotal))
        try {
            for (f in m.files) {
                val out = File(dir(ctx), f.name)
                if (out.exists()) { done += out.length(); continue }
                done += downloadOne(ctx, m, f, done)
            }
            setUi(m.id, Ui(Status.READY, done, done))
            select(ctx, m.id)
        } catch (e: CancellationException) {
            refreshOne(ctx, m)
            throw e
        } catch (e: Exception) {
            setUi(m.id, Ui(Status.FAILED, haveOf(ctx, m), m.approxTotal, e.message ?: "خطأ غير معروف"))
        }
    }

    private fun haveOf(ctx: Context, m: ModelInfo): Long {
        var have = 0L
        for (f in m.files) {
            val o = File(dir(ctx), f.name)
            val p = File(dir(ctx), f.name + ".part")
            have += if (o.exists()) o.length() else if (p.exists()) p.length() else 0L
        }
        return have
    }

    private fun refreshOne(ctx: Context, m: ModelInfo) {
        setUi(m.id, Ui(Status.ABSENT, haveOf(ctx, m), m.approxTotal))
    }

    /** يحمّل ملف واحد (مع الاستكمال) ويرجّع حجمه النهائي */
    private suspend fun downloadOne(ctx: Context, m: ModelInfo, f: ModelFile, base: Long): Long {
        val part = File(dir(ctx), f.name + ".part")
        val out = File(dir(ctx), f.name)
        var have = if (part.exists()) part.length() else 0L
        val conn = (URL(f.url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20000
            readTimeout = 30000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "iChat/0.7")
            if (have > 0) setRequestProperty("Range", "bytes=$have-")
        }
        val code = conn.responseCode
        if (code != 200 && code != 206) throw IOException("رد الخادم: $code")
        val len = conn.contentLengthLong
        if (code == 200) have = 0L
        val total = if (len > 0) have + len else f.approx
        val need = (total - have) + 300L * 1024 * 1024
        if (StatFs(dir(ctx).path).availableBytes < need) {
            throw IOException("المساحة مش كفاية. محتاج حوالي ${need / (1024 * 1024)} ميجا فاضية.")
        }
        conn.inputStream.use { input ->
            FileOutputStream(part, code == 206).use { fos ->
                val buf = ByteArray(64 * 1024)
                var lastUi = 0L
                while (true) {
                    coroutineContext.ensureActive()
                    val n = input.read(buf)
                    if (n < 0) break
                    fos.write(buf, 0, n)
                    have += n
                    val now = System.currentTimeMillis()
                    if (now - lastUi > 300) {
                        lastUi = now
                        setUi(m.id, Ui(Status.DOWNLOADING, base + have, m.approxTotal))
                    }
                }
            }
        }
        if (len > 0 && part.length() != total) throw IOException("الملف اتحمل ناقص، اضغط استكمال.")
        if (!part.renameTo(out)) throw IOException("فشل حفظ الملف.")
        return out.length()
    }
}
