package com.ichat.offline.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.TextUnitType

@Composable
fun IChatTheme(dark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (dark) darkColorScheme(
        primary = Color(0xFF2BA8FF), onPrimary = Color(0xFF00263F),
        primaryContainer = Color(0xFF1B4F8F), onPrimaryContainer = Color(0xFFFFFFFF),
        background = Color(0xFF0A1126), surface = Color(0xFF0A1126),
        surfaceVariant = Color(0xFF111D3A), onSurfaceVariant = Color(0xFFC3CEE6),
        outlineVariant = Color(0xFF1E3A5F)
    ) else lightColorScheme(
        primary = Color(0xFF0B6BCB), onPrimary = Color(0xFFFFFFFF),
        primaryContainer = Color(0xFFD6E8FF), onPrimaryContainer = Color(0xFF001B3D),
        background = Color(0xFFF5F8FF), surface = Color(0xFFF5F8FF),
        surfaceVariant = Color(0xFFE3EBF8), onSurfaceVariant = Color(0xFF3A4660),
        outlineVariant = Color(0xFFC3D0E6)
    )
    val base = MaterialTheme.typography
    val typo = base.copy(
        bodyLarge = base.bodyLarge.copy(
            fontSize = TextUnit(17f, TextUnitType.Sp), lineHeight = TextUnit(27f, TextUnitType.Sp)
        )
    )
    MaterialTheme(colorScheme = scheme, typography = typo, content = content)
}
