#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <algorithm>
#include <string>
#include <vector>
#include "llama.h"
#include "mtmd.h"
#include "mtmd-helper.h"

#define TAG "iChatLlama"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static llama_model* g_model = nullptr;
static const llama_vocab* g_vocab = nullptr;
static mtmd_context* g_mtmd = nullptr;
static int g_n_ctx = 4096;
static int g_threads = 6;
static std::atomic<bool> g_stop{false};
static bool g_backend = false;
static std::vector<llama_logit_bias> g_bias; // يحجب الحروف الصينية/اليابانية/الكورية

static bool has_cjk(const char* b, int len) {
    for (int i = 0; i + 2 < len; i++) {
        unsigned char c = (unsigned char) b[i];
        if ((c & 0xF0) == 0xE0) {
            unsigned char c1 = (unsigned char) b[i + 1], c2 = (unsigned char) b[i + 2];
            if ((c1 & 0xC0) == 0x80 && (c2 & 0xC0) == 0x80) {
                unsigned cp = ((c & 0x0Fu) << 12) | ((c1 & 0x3Fu) << 6) | (c2 & 0x3Fu);
                if ((cp >= 0x2E80 && cp <= 0x9FFF) || (cp >= 0xAC00 && cp <= 0xD7AF) ||
                    (cp >= 0xF900 && cp <= 0xFAFF) || (cp >= 0xFF00 && cp <= 0xFFEF)) return true;
            }
        }
    }
    return false;
}

static size_t utf8_complete_prefix(const std::string& s) {
    size_t n = s.size();
    if (n == 0) return 0;
    size_t i = n;
    int back = 0;
    while (i > 0 && back < 4) {
        i--; back++;
        unsigned char c = (unsigned char) s[i];
        if ((c & 0xC0) != 0x80) {
            int need = (c < 0x80) ? 1 : ((c & 0xE0) == 0xC0) ? 2 : ((c & 0xF0) == 0xE0) ? 3 : ((c & 0xF8) == 0xF0) ? 4 : 1;
            if (need > back) return i;
            return n;
        }
    }
    return n;
}

static void free_all() {
    if (g_mtmd) { mtmd_free(g_mtmd); g_mtmd = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; g_vocab = nullptr; }
}

// يرجّع: 0 تمام، 1 فشل تحميل النموذج، 2 النموذج اتحمل لكن ملف الصور فشل
extern "C" JNIEXPORT jint JNICALL
Java_com_ichat_offline_engine_LlamaBridge_nativeLoad(JNIEnv* env, jobject, jstring jpath, jstring jmm, jint nCtx, jint nThreads) {
    if (!g_backend) { llama_backend_init(); g_backend = true; }
    free_all();
    const char* path = env->GetStringUTFChars(jpath, nullptr);
    const char* mm = env->GetStringUTFChars(jmm, nullptr);
    std::string mmpath(mm);
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    g_model = llama_model_load_from_file(path, mp);
    env->ReleaseStringUTFChars(jpath, path);
    env->ReleaseStringUTFChars(jmm, mm);
    if (!g_model) { LOGE("model load failed"); return 1; }
    g_vocab = llama_model_get_vocab(g_model);
    g_n_ctx = nCtx;
    g_threads = nThreads;

    g_bias.clear();
    {
        int nv = llama_vocab_n_tokens(g_vocab);
        char tb[128];
        for (int t = 0; t < nv; t++) {
            int l = llama_token_to_piece(g_vocab, t, tb, sizeof(tb), 0, false);
            if (l > 0 && has_cjk(tb, l)) g_bias.push_back({t, -100.0f});
        }
    }

    if (!mmpath.empty()) {
        mtmd_context_params cp = mtmd_context_params_default();
        cp.use_gpu = false;
        cp.n_threads = nThreads;
        cp.print_timings = false;
        g_mtmd = mtmd_init_from_file(mmpath.c_str(), g_model, cp);
        if (!g_mtmd) { LOGE("mmproj load failed"); return 2; }
    }
    return 0;
}

extern "C" JNIEXPORT void JNICALL
Java_com_ichat_offline_engine_LlamaBridge_nativeUnload(JNIEnv*, jobject) { free_all(); }

extern "C" JNIEXPORT void JNICALL
Java_com_ichat_offline_engine_LlamaBridge_nativeStop(JNIEnv*, jobject) { g_stop = true; }

// أكواد الرجوع: 0 تمام، -1 مفيش نموذج، -2 فشل التقسيم، -3 طويل أوي، -4 فشل فك، -5 فشل السياق، -6 فشل معالجة الصورة
extern "C" JNIEXPORT jint JNICALL
Java_com_ichat_offline_engine_LlamaBridge_nativeGenerate(JNIEnv* env, jobject, jbyteArray jprompt, jbyteArray jimg,
                                                         jint imgW, jint imgH, jint maxTokens, jint nCtx, jobject cb) {
    if (!g_model) return -1;
    g_stop = false;

    jclass cls = env->GetObjectClass(cb);
    jmethodID mid = env->GetMethodID(cls, "onToken", "([B)Z");
    if (!mid) return -5;

    jsize plen = env->GetArrayLength(jprompt);
    std::string prompt((size_t) plen, '\0');
    env->GetByteArrayRegion(jprompt, 0, plen, reinterpret_cast<jbyte*>(&prompt[0]));

    bool hasImg = (jimg != nullptr) && g_mtmd && imgW > 0 && imgH > 0;
    std::vector<llama_token> toks;
    int n = 0;
    if (!hasImg) {
        n = -llama_tokenize(g_vocab, prompt.c_str(), (int) prompt.size(), nullptr, 0, false, true);
        if (n <= 0) return -2;
        toks.resize(n);
        if (llama_tokenize(g_vocab, prompt.c_str(), (int) prompt.size(), toks.data(), n, false, true) < 0) return -2;
        if (n + 16 > nCtx) return -3;
    }

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = nCtx;
    cp.n_batch = 512;
    cp.n_threads = g_threads;
    cp.n_threads_batch = g_threads;
    llama_context* ctx = llama_init_from_model(g_model, cp);
    if (!ctx) return -5;

    llama_sampler* smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(smpl, llama_sampler_init_logit_bias(llama_vocab_n_tokens(g_vocab), (int) g_bias.size(), g_bias.data()));
    llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(0.5f));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    int rc = 0;
    llama_pos n_past = 0;

    if (hasImg) {
        jsize il = env->GetArrayLength(jimg);
        std::vector<unsigned char> rgb((size_t) il);
        env->GetByteArrayRegion(jimg, 0, il, reinterpret_cast<jbyte*>(rgb.data()));
        mtmd_bitmap* bmp = mtmd_bitmap_init((uint32_t) imgW, (uint32_t) imgH, rgb.data());
        mtmd_input_chunks* chunks = mtmd_input_chunks_init();
        mtmd_input_text txt;
        txt.text = prompt.c_str();
        txt.add_special = false;
        txt.parse_special = true;
        const mtmd_bitmap* bms[1] = { bmp };
        int32_t r = mtmd_tokenize(g_mtmd, chunks, &txt, bms, 1);
        if (r != 0) {
            LOGE("mtmd_tokenize failed: %d", r);
            rc = -6;
        } else if ((int) mtmd_helper_get_n_tokens(chunks) + 16 > nCtx) {
            rc = -3;
        } else if (mtmd_helper_eval_chunks(g_mtmd, ctx, chunks, 0, 0, (int) cp.n_batch, true, &n_past) != 0) {
            rc = -6;
        }
        mtmd_input_chunks_free(chunks);
        mtmd_bitmap_free(bmp);
    } else {
        for (int i = 0; i < n && !g_stop; i += (int) cp.n_batch) {
            int c = std::min((int) cp.n_batch, n - i);
            llama_batch b = llama_batch_get_one(toks.data() + i, c);
            if (llama_decode(ctx, b) != 0) { rc = -4; break; }
        }
        n_past = n;
    }

    int maxNew = std::min((int) maxTokens, nCtx - (int) n_past - 8);
    llama_batch one = llama_batch_init(1, 0, 1);
    std::string pending;
    char buf[256];
    std::vector<llama_token> recent; // آخر التوكنز المتولدة (لمنع التكرار)
    const int n_vocab = llama_vocab_n_tokens(g_vocab);
    for (int step = 0; rc == 0 && !g_stop && step < maxNew; step++) {
        if (!recent.empty()) {
            float* lg = llama_get_logits_ith(ctx, -1);
            if (lg) {
                size_t take = std::min((size_t) 128, recent.size());
                std::vector<llama_token> u(recent.end() - take, recent.end());
                std::sort(u.begin(), u.end());
                u.erase(std::unique(u.begin(), u.end()), u.end());
                for (llama_token t : u) {
                    if (t >= 0 && t < n_vocab) lg[t] = lg[t] > 0 ? lg[t] / 1.1f : lg[t] * 1.1f;
                }
            }
        }
        llama_token id = llama_sampler_sample(smpl, ctx, -1);
        recent.push_back(id);
        if (llama_vocab_is_eog(g_vocab, id)) break;
        int len = llama_token_to_piece(g_vocab, id, buf, sizeof(buf), 0, true);
        if (len > 0) pending.append(buf, (size_t) len);
        size_t k = utf8_complete_prefix(pending);
        if (k > 0) {
            jbyteArray arr = env->NewByteArray((jsize) k);
            env->SetByteArrayRegion(arr, 0, (jsize) k, reinterpret_cast<const jbyte*>(pending.data()));
            pending.erase(0, k);
            jboolean cont = env->CallBooleanMethod(cb, mid, arr);
            env->DeleteLocalRef(arr);
            if (env->ExceptionCheck()) { env->ExceptionClear(); break; }
            if (!cont) break;
        }
        one.n_tokens = 1;
        one.token[0] = id;
        one.pos[0] = n_past;
        one.n_seq_id[0] = 1;
        one.seq_id[0][0] = 0;
        one.logits[0] = 1;
        if (llama_decode(ctx, one) != 0) { rc = -4; break; }
        n_past++;
    }

    llama_batch_free(one);
    llama_sampler_free(smpl);
    llama_free(ctx);
    return rc;
}
