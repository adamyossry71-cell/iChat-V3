package com.ichat.offline.engine

import com.ichat.offline.data.MessageEntity
import kotlinx.coroutines.asCoroutineDispatcher
import java.util.concurrent.Executors

interface TokenCallback {
    /** يرجّع true للاستمرار، false للإيقاف */
    fun onToken(bytes: ByteArray): Boolean
}

object LlamaBridge {
    init { System.loadLibrary("ichat_llama") }
    external fun nativeLoad(path: String, mmproj: String, nCtx: Int, nThreads: Int): Int
    external fun nativeGenerate(prompt: ByteArray, rgb: ByteArray?, w: Int, h: Int, maxTokens: Int, cb: TokenCallback): Int
    external fun nativeStop()
    external fun nativeUnload()
}

/** كل عمليات المحرك بتتنفذ على thread واحد عشان الأمان */
object LlamaEngine {
    val dispatcher = Executors.newSingleThreadExecutor { r -> Thread(null, r, "llama", 8L * 1024 * 1024) }.asCoroutineDispatcher()
    private var key: String? = null
    var visionReady = false
        private set

    /** عدد خيوط مناسب للجهاز: يسيب نواة للنظام ويتراوح بين 4 و 8 */
    private fun recommendedThreads(): Int {
        val cores = Runtime.getRuntime().availableProcessors()
        return (cores - 1).coerceIn(4, 8)
    }

    fun ensureLoaded(path: String, mmproj: String?, nCtx: Int): Boolean {
        val threads = recommendedThreads()
        val k = "$path|$mmproj|$nCtx|$threads"
        if (k == key) return true
        val rc = LlamaBridge.nativeLoad(path, mmproj ?: "", nCtx, threads)
        if (rc == 1) { key = null; visionReady = false; return false }
        visionReady = (rc == 0 && mmproj != null)
        key = k
        return true
    }

    fun unload() {
        LlamaBridge.nativeUnload()
        key = null
        visionReady = false
    }
}

object PromptBuilder {
    const val DEFAULT_SYSTEM =
        "أنت iChat، مساعد ذكي يعمل على هاتف المستخدم. " +
        "افهم العامية المصرية والأخطاء الإملائية (مثال: «كود لاله حاسبه» = كود آلة حاسبة). " +
        "أجب بعربية فصحى مبسطة وواضحة وجمل قصيرة؛ وبالإنجليزية إذا كتب المستخدم بالإنجليزية. " +
        "نفّذ الطلب مباشرة دون مقدمات طويلة، ولا تسأل إلا إذا كان الطلب غامضًا تمامًا. " +
        "لا تخترع أرقامًا أو حقائق أو مصادر. إذا لم تكن متأكدًا فقل ذلك صراحة. " +
        "في البرمجة: كود كامل يعمل داخل مربع كود ثم شرح مختصر جدًا. " +
        "في المسائل الدراسية: حل خطوة بخطوة مع النتيجة النهائية واضحة. " +
        "إذا أُرسلت صورة فيها أسئلة: انسخ نص الأسئلة أولًا ثم حل كل سؤال؛ " +
        "وإن كان جزء غير واضح فاذكر ذلك ولا تخمّن."

    const val MEDIA_MARKER = "<__media__>"

    data class Built(val prompt: String, val imagePath: String?)

    /** صيغة ChatML المستخدمة في نماذج Qwen */
    fun build(history: List<MessageEntity>, system: String = DEFAULT_SYSTEM): Built {
        val turns = history.filter { it.role == "user" || it.role == "assistant" }
        val kept = ArrayDeque<MessageEntity>()
        var chars = 0
        // نحتفظ بسياق أحدث وأطول شوية عشان الرد أذكى مع الحفاظ على السرعة
        for (m in turns.asReversed()) {
            chars += m.content.length
            if (chars > 9000 && kept.isNotEmpty()) break
            kept.addFirst(m)
        }
        val lastImg = kept.lastOrNull { it.role == "user" && it.imagePath != null }
        val sb = StringBuilder()
        sb.append("<|im_start|>system\n").append(system).append("<|im_end|>\n")
        for (m in kept) {
            val content = when {
                lastImg != null && m.id == lastImg.id -> MEDIA_MARKER + "\n" + m.content
                m.imagePath != null -> "[صورة سابقة]\n" + m.content
                else -> m.content
            }
            sb.append("<|im_start|>").append(m.role).append('\n').append(content).append("<|im_end|>\n")
        }
        sb.append("<|im_start|>assistant\n")
        return Built(sb.toString(), lastImg?.imagePath)
    }
}
