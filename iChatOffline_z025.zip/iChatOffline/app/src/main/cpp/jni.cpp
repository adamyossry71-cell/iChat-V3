#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <algorithm>
#include <string>
#include <vector>
#include "llama.h"
#include "mtmd.h"
#include "mtmd-helper.h"

#define TAG "iChatLlama"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static llama_model* g_model = nullptr;
static const llama_vocab* g_vocab = nullptr;
static mtmd_context* g_mtmd = nullptr;
static llama_context* g_ctx = nullptr;
static int g_n_ctx = 4096;
static int g_threads = 6;
static std::atomic<bool> g_stop{false};
static bool g_backend = false;
static std::vector<llama_logit_bias> g_bias;

// حالة الـ KV cache بين الردود (نص فقط)
static std::vector<llama_token> g_past_tokens;
static llama_pos g_n_past = 0;
static bool g_has_image_session = false;

static bool has_cjk(const char* b, int len) {
    for (int i = 0; i + 2 < len; i++) {
        unsigned char c = (unsigned char) b[i];
        if ((c & 0xF0) == 0xE0) {
            unsigned char c1 = (unsigned char) b[i + 1], c2 = (unsigned char) b[i + 2];
            if ((c1 & 0xC0) == 0x80 && (c2 & 0xC0) == 0x80) {
                unsigned cp = ((c & 0x0Fu) << 12) | ((c1 & 0x3Fu) << 6) | (c2 & 0x3Fu);
                if ((cp >= 0x2E80 && cp <= 0x9FFF) || (cp >= 0xAC00 && cp <= 0xD7AF) ||
                    (cp >= 0xF900 && cp <= 0xFAFF) || (cp >= 0xFF00 && cp <= 0xFFEF)) return true;
            }
        }
    }
    return false;
}

static size_t utf8_complete_prefix(const std::string& s) {
    size_t n = s.size();
    if (n == 0) return 0;
    size_t i = n;
    int back = 0;
    while (i > 0 && back < 4) {
        i--; back++;
        unsigned char c = (unsigned char) s[i];
        if ((c & 0xC0) != 0x80) {
            int need = (c < 0x80) ? 1 : ((c & 0xE0) == 0xC0) ? 2 : ((c & 0xF0) == 0xE0) ? 3 : ((c & 0xF8) == 0xF0) ? 4 : 1;
            if (need > back) return i;
            return n;
        }
    }
    return n;
}

static void free_ctx() {
    if (g_ctx) {
        llama_free(g_ctx);
        g_ctx = nullptr;
    }
    g_past_tokens.clear();
    g_n_past = 0;
    g_has_image_session = false;
}

static void free_all() {
    free_ctx();
    if (g_mtmd) { mtmd_free(g_mtmd); g_mtmd = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; g_vocab = nullptr; }
}

static int common_prefix_len(const std::vector<llama_token>& a, const std::vector<llama_token>& b) {
    int n = (int) std::min(a.size(), b.size());
    int i = 0;
    for (; i < n; i++) if (a[i] != b[i]) break;
    return i;
}

// يرجّع: 0 تمام، 1 فشل تحميل النموذج، 2 النموذج اتحمل لكن ملف الصور فشل
extern "C" JNIEXPORT jint JNICALL
Java_com_ichat_offline_engine_LlamaBridge_nativeLoad(JNIEnv* env, jobject, jstring jpath, jstring jmm, jint nCtx, jint nThreads) {
    if (!g_backend) { llama_backend_init(); g_backend = true; }
    free_all();
    const char* path = env->GetStringUTFChars(jpath, nullptr);
    const char* mm = env->GetStringUTFChars(jmm, nullptr);
    std::string mmpath(mm);
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 99;
    // use_mmap / use_mlock اتشالوا من llama_model_params في الإصدارات الجديدة
    g_model = llama_model_load_from_file(path, mp);
    env->ReleaseStringUTFChars(jpath, path);
    env->ReleaseStringUTFChars(jmm, mm);
    if (!g_model) { LOGE("model load failed"); return 1; }
    g_vocab = llama_model_get_vocab(g_model);
    g_n_ctx = nCtx > 0 ? nCtx : 4096;
    g_threads = nThreads > 0 ? nThreads : 4;

    g_bias.clear();
    {
        int nv = llama_vocab_n_tokens(g_vocab);
        char tb[128];
        const int step = nv > 80000 ? 2 : 1;
        for (int t = 0; t < nv; t += step) {
            int l = llama_token_to_piece(g_vocab, t, tb, sizeof(tb), 0, false);
            if (l > 0 && has_cjk(tb, l)) g_bias.push_back({t, -80.0f});
        }
    }

    if (!mmpath.empty()) {
        mtmd_context_params cp = mtmd_context_params_default();
        cp.use_gpu = true;
        cp.n_threads = g_threads;
        cp.print_timings = false;
        g_mtmd = mtmd_init_from_file(mmpath.c_str(), g_model, cp);
        if (!g_mtmd) { LOGE("mmproj load failed"); return 2; }
    }
    return 0;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_ichat_offline_engine_LlamaBridge_nativeMarker(JNIEnv* env, jobject) {
    return env->NewStringUTF(mtmd_default_marker());
}

extern "C" JNIEXPORT void JNICALL
Java_com_ichat_offline_engine_LlamaBridge_nativeUnload(JNIEnv*, jobject) { free_all(); }

extern "C" JNIEXPORT void JNICALL
Java_com_ichat_offline_engine_LlamaBridge_nativeStop(JNIEnv*, jobject) { g_stop = true; }

// إعادة ضبط الـ KV (محادثة جديدة / regenerate)
extern "C" JNIEXPORT void JNICALL
Java_com_ichat_offline_engine_LlamaBridge_nativeResetSession(JNIEnv*, jobject) {
    free_ctx();
}

static bool ensure_ctx(int nCtx) {
    if (g_ctx && g_n_ctx >= nCtx) return true;
    free_ctx();
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = nCtx;
    cp.n_batch = 512;
    cp.n_ubatch = 256;
    cp.n_threads = g_threads;
    cp.n_threads_batch = g_threads;
    g_ctx = llama_init_from_model(g_model, cp);
    g_n_ctx = nCtx;
    return g_ctx != nullptr;
}

// أكواد: 0 تمام، سالب = خطأ
extern "C" JNIEXPORT jint JNICALL
Java_com_ichat_offline_engine_LlamaBridge_nativeGenerate(JNIEnv* env, jobject, jbyteArray jprompt, jbyteArray jimg,
                                                         jint imgW, jint imgH, jint maxTokens, jint nCtx, jobject cb) {
    if (!g_model) return -1;
    g_stop = false;

    jclass cls = env->GetObjectClass(cb);
    jmethodID mid = env->GetMethodID(cls, "onToken", "([B)Z");
    if (!mid) return -5;

    jsize plen = env->GetArrayLength(jprompt);
    std::string prompt((size_t) plen, '\0');
    env->GetByteArrayRegion(jprompt, 0, plen, reinterpret_cast<jbyte*>(&prompt[0]));

    bool hasImg = (jimg != nullptr) && g_mtmd && imgW > 0 && imgH > 0;
    int rc = 0;
    llama_pos n_past = 0;

    // الصور: مسار كامل (ما نعملش KV reuse مع vision عشان التعقيد والدقة)
    if (hasImg) {
        free_ctx();
        if (!ensure_ctx(nCtx)) return -5;
        g_has_image_session = true;

        jsize il = env->GetArrayLength(jimg);
        std::vector<unsigned char> rgb((size_t) il);
        env->GetByteArrayRegion(jimg, 0, il, reinterpret_cast<jbyte*>(rgb.data()));
        mtmd_bitmap* bmp = mtmd_bitmap_init((uint32_t) imgW, (uint32_t) imgH, rgb.data());
        mtmd_input_chunks* chunks = mtmd_input_chunks_init();
        mtmd_input_text txt;
        txt.text = prompt.c_str();
        txt.add_special = false;
        txt.parse_special = true;
        const mtmd_bitmap* bms[1] = { bmp };
        int32_t r = mtmd_tokenize(g_mtmd, chunks, &txt, bms, 1);
        if (r != 0) {
            LOGE("mtmd_tokenize failed: %d", r);
            rc = -(100 + r);
        } else if ((int) mtmd_helper_get_n_tokens(chunks) + 16 > nCtx) {
            rc = -3;
        } else if (mtmd_helper_eval_chunks(g_mtmd, g_ctx, chunks, 0, 0, 512, true, &n_past) != 0) {
            LOGE("mtmd_helper_eval_chunks failed");
            rc = -110;
        }
        mtmd_input_chunks_free(chunks);
        mtmd_bitmap_free(bmp);
        g_past_tokens.clear();
        g_n_past = n_past;
    } else {
        // نص: حاول نعيد استخدام الـ KV
        int n = -llama_tokenize(g_vocab, prompt.c_str(), (int) prompt.size(), nullptr, 0, false, true);
        if (n <= 0) return -2;
        std::vector<llama_token> toks(n);
        if (llama_tokenize(g_vocab, prompt.c_str(), (int) prompt.size(), toks.data(), n, false, true) < 0) return -2;
        if (n + 32 > nCtx) return -3;

        int prefix = 0;
        bool can_reuse = g_ctx && !g_has_image_session && !g_past_tokens.empty() && g_n_past > 0;
        if (can_reuse) {
            prefix = common_prefix_len(g_past_tokens, toks);
            // لازم يبقى جزء معقول مشترك، وإلا أعد من الصفر
            if (prefix < 32 || prefix >= n) {
                can_reuse = false;
                prefix = 0;
            }
        }

        if (!can_reuse) {
            free_ctx();
            if (!ensure_ctx(nCtx)) return -5;
            prefix = 0;
        } else {
            // اقطع الـ KV لحد البادئة المشتركة (API الحديث في llama.cpp)
            if (prefix < (int) g_n_past) {
                llama_memory_seq_rm(llama_get_memory(g_ctx), 0, prefix, -1);
                g_n_past = prefix;
            }
        }

        // قيّم التوكنز الجديدة فقط (بمواضع صحيحة من prefix)
        g_n_past = prefix;
        for (int i = prefix; i < n && !g_stop; ) {
            int c = std::min(512, n - i);
            llama_batch batch = llama_batch_init(c, 0, 1);
            for (int j = 0; j < c; j++) {
                batch.token[j] = toks[i + j];
                batch.pos[j] = g_n_past + j;
                batch.n_seq_id[j] = 1;
                batch.seq_id[j][0] = 0;
                batch.logits[j] = (j == c - 1) ? 1 : 0;
            }
            batch.n_tokens = c;
            if (llama_decode(g_ctx, batch) != 0) {
                llama_batch_free(batch);
                rc = -4;
                break;
            }
            llama_batch_free(batch);
            g_n_past += c;
            i += c;
        }
        n_past = g_n_past;
        if (rc == 0) g_past_tokens.assign(toks.begin(), toks.end());
        else g_past_tokens.clear();
        g_has_image_session = false;
    }

    if (rc != 0) {
        free_ctx();
        return rc;
    }

    // التوليد
    llama_sampler* smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    if (!g_bias.empty()) {
        llama_sampler_chain_add(smpl, llama_sampler_init_logit_bias(llama_vocab_n_tokens(g_vocab), (int) g_bias.size(), g_bias.data()));
    }
    llama_sampler_chain_add(smpl, llama_sampler_init_top_k(30));
    llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(0.55f));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    int maxNew = std::min((int) maxTokens, nCtx - (int) n_past - 8);
    llama_batch one = llama_batch_init(1, 0, 1);
    std::string pending;
    char buf[256];
    std::vector<llama_token> recent;
    recent.reserve(64);
    const int n_vocab = llama_vocab_n_tokens(g_vocab);
    std::vector<llama_token> gen_tokens;
    gen_tokens.reserve(maxNew);

    for (int step = 0; rc == 0 && !g_stop && step < maxNew; step++) {
        if (!recent.empty() && (step & 3) == 0) {
            float* lg = llama_get_logits_ith(g_ctx, -1);
            if (lg) {
                size_t take = std::min((size_t) 48, recent.size());
                for (size_t i = recent.size() - take; i < recent.size(); i++) {
                    llama_token t = recent[i];
                    if (t >= 0 && t < n_vocab) {
                        lg[t] = lg[t] > 0 ? lg[t] / 1.08f : lg[t] * 1.08f;
                    }
                }
            }
        }
        llama_token id = llama_sampler_sample(smpl, g_ctx, -1);
        recent.push_back(id);
        if ((int) recent.size() > 64) recent.erase(recent.begin(), recent.begin() + 16);
        if (llama_vocab_is_eog(g_vocab, id)) break;

        gen_tokens.push_back(id);
        int len = llama_token_to_piece(g_vocab, id, buf, sizeof(buf), 0, true);
        if (len > 0) pending.append(buf, (size_t) len);
        size_t k = utf8_complete_prefix(pending);
        if (k > 0) {
            jbyteArray arr = env->NewByteArray((jsize) k);
            env->SetByteArrayRegion(arr, 0, (jsize) k, reinterpret_cast<const jbyte*>(pending.data()));
            pending.erase(0, k);
            jboolean cont = env->CallBooleanMethod(cb, mid, arr);
            env->DeleteLocalRef(arr);
            if (env->ExceptionCheck()) { env->ExceptionClear(); break; }
            if (!cont) break;
        }
        one.n_tokens = 1;
        one.token[0] = id;
        one.pos[0] = n_past;
        one.n_seq_id[0] = 1;
        one.seq_id[0][0] = 0;
        one.logits[0] = 1;
        if (llama_decode(g_ctx, one) != 0) { rc = -4; break; }
        n_past++;
    }

    if (rc == 0 && !pending.empty() && !g_stop) {
        jbyteArray arr = env->NewByteArray((jsize) pending.size());
        env->SetByteArrayRegion(arr, 0, (jsize) pending.size(), reinterpret_cast<const jbyte*>(pending.data()));
        env->CallBooleanMethod(cb, mid, arr);
        env->DeleteLocalRef(arr);
        if (env->ExceptionCheck()) env->ExceptionClear();
    }

    // حدّث حالة الـ cache بعد التوليد (للرد الجاي)
    g_n_past = n_past;
    if (!hasImg) {
        g_past_tokens.insert(g_past_tokens.end(), gen_tokens.begin(), gen_tokens.end());
    } else {
        // بعد صورة: نسمح بـ reuse للنص اللي بعده على نفس الجلسة
        g_past_tokens.clear();
        g_has_image_session = false;
    }

    llama_batch_free(one);
    llama_sampler_free(smpl);
    // ما نمسّحش g_ctx — ده أساس التسريع بين الرسائل
    return rc;
}
