package com.ichat.offline

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ichat.offline.data.*
import com.ichat.offline.engine.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class StreamState(val id: Long, val text: String)

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()

    val chats: StateFlow<List<ChatEntity>> =
        dao.chats().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _current = MutableStateFlow<Long?>(null)
    val currentId: StateFlow<Long?> = _current

    val messages: StateFlow<List<MessageEntity>> = _current
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.messages(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _stream = MutableStateFlow<StreamState?>(null)
    val stream: StateFlow<StreamState?> = _stream
    private val _speed = MutableStateFlow<String?>(null)
    val speed: StateFlow<String?> = _speed
    private val _pending = MutableStateFlow<String?>(null)
    val pendingImage: StateFlow<String?> = _pending
    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice
    fun clearNotice() { _notice.value = null }
    fun clearPending() { _pending.value = null }

    private val _cropSource = MutableStateFlow<String?>(null)
    val cropSource: StateFlow<String?> = _cropSource
    fun cropCancel() { _cropSource.value = null }
    fun cropConfirm(l: Float, t: Float, r: Float, b: Float) {
        val src = _cropSource.value ?: return
        _cropSource.value = null
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            val side = app.getSharedPreferences("settings", 0).getInt("img_side", 896)
            val f = ImageUtil.cropAndSave(app, src, l, t, r, b, side)
            if (f != null) _pending.value = f.path else _notice.value = "فشل قص الصورة. جرّب تاني."
        }
    }
    fun cropFull() {
        val src = _cropSource.value ?: return
        _cropSource.value = null
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            val side = app.getSharedPreferences("settings", 0).getInt("img_side", 896)
            val bmp = android.graphics.BitmapFactory.decodeFile(src) ?: run {
                _notice.value = "مقدرتش أفتح الصورة."; return@launch
            }
            val s = maxOf(bmp.width, bmp.height)
            val out = if (s > side) {
                val k = side.toFloat() / s
                android.graphics.Bitmap.createScaledBitmap(
                    bmp, maxOf(1, (bmp.width * k).toInt()), maxOf(1, (bmp.height * k).toInt()), true
                )
            } else bmp
            _pending.value = ImageUtil.save(app, out).path
        }
    }

    fun canAttach(): Boolean {
        if (!ModelStore.selectedInfo().vision || !ModelStore.isReady(getApplication())) {
            _notice.value = "النموذج المختار دلوقتي مش بيدعم الصور. من القائمة افتح «تحميل نموذج الذكاء الاصطناعي» ونزّل Qwen3-VL-4B أو 8B (وبعدها اختاره)."
            return false
        }
        return true
    }

    fun attachImage(uri: Uri) {
        if (!ModelStore.selectedInfo().vision || !ModelStore.isReady(getApplication())) {
            _notice.value = "النموذج المختار دلوقتي مش بيدعم الصور. من القائمة افتح «تحميل نموذج الذكاء الاصطناعي» ونزّل Qwen3-VL-4B أو 8B (وبعدها اختاره)."
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            val bmp = ImageUtil.loadScaled(app, uri, 1600)
            if (bmp == null) { _notice.value = "مقدرتش أفتح الصورة دي. جرّب صورة تانية."; return@launch }
            _cropSource.value = ImageUtil.save(app, bmp).path
        }
    }

    private val _generating = MutableStateFlow(false)
    val generating: StateFlow<Boolean> = _generating

    init { ModelStore.refresh(app) }

    fun open(id: Long) {
        if (!_generating.value) {
            if (_current.value != id) LlamaEngine.resetSession()
            _current.value = id
        }
    }
    fun newChat() {
        if (!_generating.value) {
            LlamaEngine.resetSession()
            _current.value = null
        }
    }

    fun send(text: String) {
        val img = _pending.value
        val clean = text.trim().ifEmpty {
            if (img != null) "اقرأ كل اللي في الصورة وحل الأسئلة اللي فيها خطوة بخطوة، ولو مفيش أسئلة اشرحلي الصورة." else ""
        }
        if (clean.isEmpty() || _generating.value) return
        if (img != null && !ModelStore.selectedInfo().vision) {
            _notice.value = "النموذج المختار مش بيدعم الصور. اختار Qwen3-VL-4B أو 8B من شاشة النماذج."
            return
        }
        _pending.value = null
        _generating.value = true
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            var id = _current.value
            if (id == null) {
                id = dao.insertChat(ChatEntity(title = (if (img != null) "🖼️ " else "") + clean.take(40), updatedAt = now))
                _current.value = id
            }
            dao.insertMessage(MessageEntity(chatId = id, role = "user", content = clean, createdAt = now, imagePath = img))
            val aid = dao.insertMessage(MessageEntity(chatId = id, role = "assistant", content = "…", createdAt = now + 1))
            dao.touch(id, now)
            generate(id, aid, now + 1)
        }
    }

    fun regenerate() {
        val chatId = _current.value ?: return
        val last = messages.value.lastOrNull() ?: return
        if (last.role == "user" || _generating.value) return
        _generating.value = true
        LlamaEngine.resetSession() // إعادة من الصفر عشان ما نكملش على رد قديم
        viewModelScope.launch {
            dao.deleteMessage(last.id)
            val now = System.currentTimeMillis()
            val aid = dao.insertMessage(MessageEntity(chatId = chatId, role = "assistant", content = "…", createdAt = now))
            generate(chatId, aid, now)
        }
    }

    fun stop() { LlamaBridge.nativeStop() }

    /** مشاركة نص المحادثة الحالية */
    fun shareChat(ctx: Context) {
        val list = messages.value
        if (list.isEmpty()) {
            _notice.value = "مفيش محادثة تتشارك."
            return
        }
        val sb = StringBuilder()
        sb.append("محادثة من iChat\n").append("─".repeat(20)).append('\n')
        for (m in list) {
            val who = when (m.role) {
                "user" -> "أنت"
                "assistant" -> "iChat"
                else -> m.role
            }
            sb.append(who).append(":\n").append(m.content).append("\n\n")
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "محادثة iChat")
            putExtra(Intent.EXTRA_TEXT, sb.toString())
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(Intent.createChooser(intent, "مشاركة المحادثة").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun thermalHot(app: Application): Boolean =
        if (Build.VERSION.SDK_INT >= 29) {
            val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.currentThermalStatus >= PowerManager.THERMAL_STATUS_MODERATE
        } else false

    private suspend fun generate(chatId: Long, aid: Long, createdAt: Long) {
        val app = getApplication<Application>()
        val file = ModelStore.modelFile(app)
        val sb = StringBuilder()
        var lastSaved = 0L
        try {
            if (!ModelStore.isReady(app)) {
                dao.updateMessage(MessageEntity(aid, chatId, "system",
                    "لسه منزّلتش نموذج الذكاء الاصطناعي. افتح القائمة واختار «تحميل نموذج الذكاء الاصطناعي».", createdAt))
                return
            }
            val history = dao.messagesOnce(chatId).filter { it.id != aid }
            var sources: List<WebSearch.Hit> = emptyList()
            val lastUser = history.lastOrNull { it.role == "user" }
            if (app.getSharedPreferences("settings", 0).getBoolean("web_search", false) &&
                lastUser != null && lastUser.imagePath == null && lastUser.content.length >= 3
            ) {
                _stream.value = StreamState(aid, "استني بدوّر على الإنترنت")
                sources = withContext(Dispatchers.IO) { WebSearch.search(lastUser.content) }
            }
            val sys = app.getSharedPreferences("settings", 0).getString("system_prompt", null)
                ?.takeIf { it.isNotBlank() } ?: PromptBuilder.DEFAULT_SYSTEM
            val built = PromptBuilder.build(history, sys, if (sources.isNotEmpty()) WebSearch.asContext(sources) else null)
            val info = ModelStore.selectedInfo()
            val mmproj = ModelStore.mmprojFile(app)?.path
            val prefs = app.getSharedPreferences("settings", 0)
            var threads = prefs.getInt("threads", 4)
            val batterySaver = prefs.getBoolean("battery_saver", false)
            if (batterySaver) threads = minOf(threads, 3)

            var hot = false
            var lastThermal = 0L
            var lastUi = 0L
            var tokens = 0
            var tFirst = 0L
            _speed.value = null
            val waitLabel = if (built.imagePath != null) "استني بقرا الصورة وبفكر" else "استني بفكر"
            var gotToken = false
            val ticker = viewModelScope.launch {
                var s = 0
                while (!gotToken) {
                    _stream.value = StreamState(aid, "$waitLabel ($s ث)")
                    kotlinx.coroutines.delay(1000)
                    s++
                }
            }
            val code = withContext(LlamaEngine.dispatcher) {
                if (!LlamaEngine.ensureLoaded(file.path, mmproj, threads)) -10
                else {
                    var rgb: ByteArray? = null
                    var iw = 0
                    var ih = 0
                    if (built.imagePath != null && LlamaEngine.visionReady) {
                        val cached = ImageUtil.cachedRgb(built.imagePath)
                        if (cached != null) {
                            rgb = cached.rgb; iw = cached.w; ih = cached.h
                        } else {
                            val bmp = android.graphics.BitmapFactory.decodeFile(built.imagePath)
                            if (bmp != null) {
                                rgb = ImageUtil.toRgb(bmp); iw = bmp.width; ih = bmp.height
                                ImageUtil.storeRgbCache(built.imagePath, rgb!!, iw, ih)
                            }
                        }
                    }
                    val prompt = if (rgb == null) built.prompt.replace(PromptBuilder.MEDIA_MARKER + "\n", "") else built.prompt
                    // أقل توكنز + ctx أصغر = أسرع بوضوح على الموبايل
                    val maxTok = when {
                        batterySaver -> 512
                        rgb != null -> 768
                        else -> 1024
                    }
                    val genCtx = if (rgb != null) minOf(info.ctx, 6144) else 3072
                    LlamaBridge.nativeGenerate(prompt.toByteArray(Charsets.UTF_8), rgb, iw, ih, maxTok, genCtx, object : TokenCallback {
                        override fun onToken(bytes: ByteArray): Boolean {
                            sb.append(String(bytes, Charsets.UTF_8))
                            val now = System.currentTimeMillis()
                            if (tokens == 0) { tFirst = now; gotToken = true }
                            tokens++
                            if (now - lastUi > 250) {
                                lastUi = now
                                _stream.value = StreamState(aid, sb.toString())
                                if (now - lastThermal > 2000) {
                                    lastThermal = now
                                    hot = thermalHot(app)
                                }
                                if (tokens > 3 && now > tFirst) {
                                    _speed.value = "⚡ " + String.format("%.1f", (tokens - 1) * 1000.0 / (now - tFirst)) +
                                        " توكن/ث" + (if (hot) " 🌡️ سخن" else "") + (if (batterySaver) " 🔋" else "")
                                }
                            }
                            // حفظ جزئي كل ~4 ثواني عشان لو التطبيق اتقفل ما نخسرش الرد
                            if (now - lastSaved > 4000 && sb.length > 20) {
                                lastSaved = now
                                viewModelScope.launch(Dispatchers.IO) {
                                    dao.updateMessage(
                                        MessageEntity(aid, chatId, "assistant", sb.toString().trim() + "…", createdAt)
                                    )
                                }
                            }
                            return true
                        }
                    })
                }
            }
            ticker.cancel()
            val text = sb.toString().trim()
            val err = PromptBuilder.errorMessage(code)
            val msg = when {
                code < 0 && text.isEmpty() -> MessageEntity(aid, chatId, "system", err.ifBlank {
                    "حصل خطأ أثناء التوليد (كود $code)."
                }, createdAt)
                code < 0 && text.isNotEmpty() -> MessageEntity(
                    aid, chatId, "assistant",
                    text + "\n\n⚠️ " + (err.ifBlank { "التوليد اتوقف (كود $code)." }),
                    createdAt
                )
                else -> MessageEntity(
                    aid, chatId, "assistant",
                    text.ifEmpty { "(مفيش رد)" } +
                        (if (sources.isNotEmpty()) "\n\n🌐 مصادر ويكيبيديا: " + sources.joinToString("، ") { it.title } else ""),
                    createdAt
                )
            }
            dao.updateMessage(msg)
        } catch (e: Exception) {
            val partial = sb.toString().trim()
            val content = if (partial.isNotEmpty()) {
                partial + "\n\n⚠️ التوليد اتقطع: ${e.message ?: "خطأ غير معروف"}"
            } else {
                "حصل خطأ: ${e.message ?: "غير معروف"}. جرب تاني."
            }
            dao.updateMessage(MessageEntity(aid, chatId, if (partial.isNotEmpty()) "assistant" else "system", content, createdAt))
        } finally {
            _stream.value = null
            _generating.value = false
            _speed.value = null
        }
    }

    fun deleteChat(id: Long) {
        viewModelScope.launch {
            if (_current.value == id) _current.value = null
            dao.deleteChat(id)
        }
    }

    fun deleteAll() {
        viewModelScope.launch { _current.value = null; dao.deleteAll() }
    }
}
