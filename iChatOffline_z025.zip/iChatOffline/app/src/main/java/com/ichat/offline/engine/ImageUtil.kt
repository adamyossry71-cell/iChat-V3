package com.ichat.offline.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import java.io.File
import java.io.FileOutputStream

object ImageUtil {
    data class RgbCache(val rgb: ByteArray, val w: Int, val h: Int)
    @Volatile private var rgbCachePath: String? = null
    @Volatile private var rgbCache: RgbCache? = null

    fun cachedRgb(path: String): RgbCache? =
        if (rgbCachePath == path) rgbCache else null

    fun storeRgbCache(path: String, rgb: ByteArray, w: Int, h: Int) {
        rgbCachePath = path
        rgbCache = RgbCache(rgb, w, h)
    }

    fun loadScaled(ctx: Context, uri: Uri, maxSide: Int): Bitmap? = try {
        if (Build.VERSION.SDK_INT >= 28) {
            val src = ImageDecoder.createSource(ctx.contentResolver, uri)
            ImageDecoder.decodeBitmap(src) { dec, info, _ ->
                dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val w = info.size.width
                val h = info.size.height
                val s = maxOf(w, h)
                if (s > maxSide) dec.setTargetSize(maxOf(1, w * maxSide / s), maxOf(1, h * maxSide / s))
            }
        } else {
            val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        }
    } catch (e: Exception) { null }

    fun save(ctx: Context, bmp: Bitmap): File {
        val dir = File(ctx.filesDir, "images").apply { mkdirs() }
        val f = File(dir, "img_${System.currentTimeMillis()}.jpg")
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        return f
    }

    /** يرجّع RGB خام (3 بايت لكل بكسل) */
    fun toRgb(bmp: Bitmap): ByteArray {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val out = ByteArray(w * h * 3)
        for (i in px.indices) {
            val p = px[i]
            out[3 * i] = (p shr 16).toByte()
            out[3 * i + 1] = (p shr 8).toByte()
            out[3 * i + 2] = p.toByte()
        }
        return out
    }

    /** يقص جزء من صورة محفوظة (نسب من 0 لـ 1) ويصغّرها لو أكبر من الحد */
    fun cropAndSave(ctx: Context, srcPath: String, l: Float, t: Float, r: Float, b: Float, maxSide: Int): File? {
        val src = BitmapFactory.decodeFile(srcPath) ?: return null
        val x = (l * src.width).toInt().coerceIn(0, src.width - 1)
        val y = (t * src.height).toInt().coerceIn(0, src.height - 1)
        val w = ((r - l) * src.width).toInt().coerceIn(1, src.width - x)
        val h = ((b - t) * src.height).toInt().coerceIn(1, src.height - y)
        var out = Bitmap.createBitmap(src, x, y, w, h)
        val s = maxOf(out.width, out.height)
        if (s > maxSide) {
            val k = maxSide.toFloat() / s
            out = Bitmap.createScaledBitmap(out, maxOf(1, (out.width * k).toInt()), maxOf(1, (out.height * k).toInt()), true)
        }
        return save(ctx, out)
    }
}
