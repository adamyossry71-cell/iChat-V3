package com.ichat.offline.engine

import com.ichat.offline.data.MessageEntity
import java.util.ArrayDeque

object LlamaEngine {
    @Volatile var visionReady = false
        private set
    private var key: String? = null
    val dispatcher = kotlinx.coroutines.Dispatchers.IO.limitedParallelism(1)

    fun ensureLoaded(path: String, mmproj: String?, threads: Int): Boolean {
        val k = "$path|$mmproj|$threads"
        if (key == k) return true
        unload()
        val rc = LlamaBridge.nativeLoad(path, mmproj ?: "", 4096, threads)
        if (rc == 0) {
            key = k
            visionReady = !mmproj.isNullOrEmpty()
            return true
        }
        if (rc == 2) {
            // model loaded but mmproj failed
            key = "$path||$threads"
            visionReady = false
            return true
        }
        return false
    }

    fun unload() {
        LlamaBridge.nativeUnload()
        key = null
        visionReady = false
    }

    /** يصفّر الـ KV cache — يستدعى مع محادثة جديدة أو إعادة توليد */
    fun resetSession() {
        try { LlamaBridge.nativeResetSession() } catch (_: Throwable) {}
    }
}

object LlamaBridge {
    external fun nativeLoad(path: String, mmproj: String, nCtx: Int, nThreads: Int): Int
    external fun nativeUnload()
    external fun nativeStop()
    external fun nativeResetSession()
    external fun nativeMarker(): String
    external fun nativeGenerate(
        prompt: ByteArray, img: ByteArray?, imgW: Int, imgH: Int,
        maxTokens: Int, nCtx: Int, cb: TokenCallback
    ): Int

    init { System.loadLibrary("ichat_llama") }
}

fun interface TokenCallback {
    fun onToken(bytes: ByteArray): Boolean
}

object PromptBuilder {
    // أقصر = prefill أسرع، مع الحفاظ على نفس السلوك
    const val DEFAULT_SYSTEM =
        "أنت iChat، مساعد على هاتف المستخدم. افهم العامية المصرية والأخطاء الإملائية. " +
        "أجب بفصحى مبسطة وجمل قصيرة، وبالإنجليزية إن كتب بها المستخدم. نفّذ الطلب مباشرة بلا أسئلة إلا للضرورة. " +
        "في البرمجة: كود كامل في مربع ثم شرح مختصر. في الدراسة: حل خطوة بخطوة. " +
        "مع صور الامتحان: اكتب ما قرأته ثم حل كل سؤال بدقة، ولا تخمّن إن كان النص غير واضح. لا تختلق معلومات."

    /** علامة الصورة الفعلية من مكتبة mtmd (بتتغير أحيانًا بين الإصدارات) */
    val MEDIA_MARKER: String
        get() = try { LlamaBridge.nativeMarker() } catch (t: Throwable) { "<__media__>" }

    data class Built(val prompt: String, val imagePath: String?)

    /**
     * إدارة سياق أذكى:
     * - يحافظ دائمًا على أول رسالة مستخدم (لو موجودة) + آخر الرسائل
     * - ميزانية أحرف أعلى مع قطع أنظف
     */
    fun build(history: List<MessageEntity>, system: String = DEFAULT_SYSTEM, extra: String? = null): Built {
        val turns = history.filter { it.role == "user" || it.role == "assistant" }
        if (turns.isEmpty()) {
            val sb = StringBuilder()
            sb.append("<|im_start|>system\n").append(system)
            if (extra != null) sb.append("\n\n").append(extra)
            sb.append("<|im_end|>\n<|im_start|>assistant\n")
            return Built(sb.toString(), null)
        }

        // ميزانية أصغر = prefill أسرع (السرعة أهم من ذاكرة طويلة على الموبايل)
        val budget = 5500
        val kept = ArrayDeque<MessageEntity>()
        var chars = 0

        for (m in turns.asReversed()) {
            val len = m.content.length + 20
            if (chars + len > budget && kept.isNotEmpty()) break
            kept.addFirst(m)
            chars += len
        }

        val firstUser = turns.firstOrNull { it.role == "user" }
        if (firstUser != null && kept.none { it.id == firstUser.id }) {
            val len = firstUser.content.length + 20
            if (chars + len <= budget + 800) {
                kept.addFirst(firstUser)
            }
        }

        val lastImg = kept.lastOrNull { it.role == "user" && it.imagePath != null }
        val sb = StringBuilder()
        sb.append("<|im_start|>system\n").append(system)
        if (extra != null) sb.append("\n\n").append(extra)
        sb.append("<|im_end|>\n")

        if (kept.size < turns.size) {
            sb.append("<|im_start|>system\n")
                .append("(تم اختصار جزء من المحادثة السابقة للحفاظ على الذاكرة)")
                .append("<|im_end|>\n")
        }

        for (m in kept) {
            val content = when {
                lastImg != null && m.id == lastImg.id -> MEDIA_MARKER + "\n" + m.content
                m.imagePath != null -> "[صورة سابقة]\n" + m.content
                else -> m.content
            }
            sb.append("<|im_start|>").append(m.role).append('\n').append(content).append("<|im_end|>\n")
        }
        sb.append("<|im_start|>assistant\n")
        return Built(sb.toString(), lastImg?.imagePath)
    }

    /** ترجمة أكواد الخطأ من الـ JNI لرسائل عربية مفهومة */
    fun errorMessage(code: Int): String = when (code) {
        -1 -> "النموذج مش محمّل في الذاكرة. جرب تاني أو أعد تحميل النموذج."
        -2 -> "فشل تقسيم النص. جرب تصغّر الرسالة أو ابدأ محادثة جديدة."
        -3 -> "المحادثة أو الصورة طويلة أوي على الذاكرة. ابدأ محادثة جديدة أو صغّر جودة الصورة من الإعدادات."
        -4 -> "فشل فك التوكنز أثناء التوليد. جرب تاني."
        -5 -> "فشل إنشاء سياق النموذج. اقفل تطبيقات تانية وجرب."
        -6 -> "فشلت معالجة الصورة. جرب صورة أوضح أو صغّر جودة الصور."
        -10 -> "فشل تحميل النموذج في الذاكرة. اقفل التطبيقات التانية، أو استخدم نموذج أصغر، أو أعد تنزيله."
        -101 -> "عدد الصور مش مطابق. جرب تاني من غير قص."
        -102 -> "فشل تجهيز الصورة للنموذج. جرب جودة أقل أو صورة تانية."
        -110 -> "فشل تحليل الصورة داخل النموذج. جرب تصغير جودة الصور من الإعدادات."
        else -> if (code < 0) "حصل خطأ أثناء التوليد (كود $code). لو استمر ابعت الكود للمطوّر." else ""
    }
}
