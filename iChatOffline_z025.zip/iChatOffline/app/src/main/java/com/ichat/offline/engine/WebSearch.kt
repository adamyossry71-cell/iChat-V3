package com.ichat.offline.engine

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** بحث اختياري في ويكيبيديا. بيتبعت نص السؤال بس، وبعد موافقة المستخدم في الإعدادات. */
object WebSearch {
    data class Hit(val title: String, val extract: String, val url: String)

    private val stop = setOf(
        "مين", "من", "ايه", "إيه", "ما", "ماذا", "هو", "هي", "في", "على", "علي", "عن", "ازاي", "إزاي", "كيف",
        "ليه", "لماذا", "متى", "امتى", "فين", "أين", "اين", "هل", "اشرح", "اشرحلي", "لي", "ليا", "قولي",
        "اللي", "الي", "ده", "دي", "هذا", "هذه", "the", "a", "an", "of", "is", "are", "what", "who", "how",
        "why", "when", "where", "tell", "me", "about"
    )

    private fun isArabic(s: String) = s.any { it in '\u0600'..'\u06FF' }

    private fun keywords(q: String): String {
        val words = q.replace(Regex("[\\p{Punct}؟،؛]"), " ").split(Regex("\\s+"))
            .filter { it.length > 1 && it.lowercase() !in stop }
            .take(6)
        return if (words.isEmpty()) q.trim().take(100) else words.joinToString(" ")
    }

    /** لازم تتنادى من خيط خلفي (مش الرئيسي) */
    fun search(query: String): List<Hit> {
        val kw = keywords(query)
        if (kw.length < 2) return emptyList()
        val lang = if (isArabic(kw)) "ar" else "en"
        val enc = URLEncoder.encode(kw, "UTF-8")
        val url = "https://$lang.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=$enc&gsrlimit=2" +
            "&prop=extracts&exintro=1&explaintext=1&exlimit=2&exchars=600&format=json&utf8=1"
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 6000
            readTimeout = 8000
            setRequestProperty("User-Agent", "iChat/0.9 (Android; offline-first assistant)")
        }
        return try {
            if (conn.responseCode != 200) return emptyList()
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val pages = JSONObject(text).optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
            val out = mutableListOf<Pair<Int, Hit>>()
            for (key in pages.keys()) {
                val p = pages.getJSONObject(key)
                val title = p.optString("title")
                val ex = p.optString("extract").trim()
                if (title.isNotEmpty() && ex.isNotEmpty()) {
                    val link = "https://$lang.wikipedia.org/wiki/" + URLEncoder.encode(title.replace(' ', '_'), "UTF-8")
                    out += p.optInt("index", 99) to Hit(title, ex, link)
                }
            }
            out.sortedBy { it.first }.map { it.second }
        } catch (e: Exception) {
            emptyList()
        } finally {
            conn.disconnect()
        }
    }

    fun asContext(hits: List<Hit>): String =
        "معلومات من ويكيبيديا للمساعدة (استخدمها إذا كانت مرتبطة مباشرة بالسؤال، وتجاهلها إذا لم تكن مرتبطة، ولا تخترع معلومات خارجها):\n" +
            hits.mapIndexed { i, h -> "[${i + 1}] ${h.title}: ${h.extract}" }.joinToString("\n")
}
