package com.ichat.offline.ui

import android.graphics.BitmapFactory
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.abs

/** شاشة قص: المستخدم يحدد السؤال اللي عايزه بس (أسرع وأدق بكتير من الصفحة كلها) */
@Composable
fun CropDialog(
    path: String,
    onConfirm: (Float, Float, Float, Float) -> Unit,
    onFull: () -> Unit,
    onCancel: () -> Unit
) {
    val bmp = remember(path) { BitmapFactory.decodeFile(path) }
    if (bmp == null) { LaunchedEffect(Unit) { onCancel() }; return }
    val img = remember(bmp) { bmp.asImageBitmap() }
    var l by remember { mutableStateOf(0.05f) }
    var t by remember { mutableStateOf(0.05f) }
    var r by remember { mutableStateOf(0.95f) }
    var b by remember { mutableStateOf(0.95f) }
    var active by remember { mutableStateOf(0) } // 1 TL, 2 TR, 3 BL, 4 BR, 5 move

    Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF0A1126)) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                Text(
                    "اسحب الإطار على السؤال اللي عايز تحله. القص الأصغر = أسرع وأدق.",
                    color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(12.dp)
                )
                BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().padding(8.dp)) {
                    val cw = constraints.maxWidth.toFloat()
                    val ch = constraints.maxHeight.toFloat()
                    val ar = bmp.width.toFloat() / bmp.height
                    val wide = cw / ch > ar
                    val dw = if (wide) ch * ar else cw
                    val dh = if (wide) ch else cw / ar
                    val ox = (cw - dw) / 2f
                    val oy = (ch - dh) / 2f
                    Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                    Canvas(
                        Modifier.fillMaxSize().pointerInput(dw, dh, ox, oy) {
                            detectDragGestures(
                                onDragStart = { p ->
                                    val fx = (p.x - ox) / dw
                                    val fy = (p.y - oy) / dh
                                    val tx = 56.dp.toPx() / dw
                                    val ty = 56.dp.toPx() / dh
                                    fun near(ax: Float, ay: Float) = abs(fx - ax) < tx && abs(fy - ay) < ty
                                    active = when {
                                        near(l, t) -> 1
                                        near(r, t) -> 2
                                        near(l, b) -> 3
                                        near(r, b) -> 4
                                        fx in l..r && fy in t..b -> 5
                                        else -> 0
                                    }
                                },
                                onDragEnd = { active = 0 },
                                onDragCancel = { active = 0 },
                                onDrag = { change, drag ->
                                    change.consume()
                                    val dx = drag.x / dw
                                    val dy = drag.y / dh
                                    when (active) {
                                        1 -> { l = (l + dx).coerceIn(0f, r - 0.05f); t = (t + dy).coerceIn(0f, b - 0.05f) }
                                        2 -> { r = (r + dx).coerceIn(l + 0.05f, 1f); t = (t + dy).coerceIn(0f, b - 0.05f) }
                                        3 -> { l = (l + dx).coerceIn(0f, r - 0.05f); b = (b + dy).coerceIn(t + 0.05f, 1f) }
                                        4 -> { r = (r + dx).coerceIn(l + 0.05f, 1f); b = (b + dy).coerceIn(t + 0.05f, 1f) }
                                        5 -> {
                                            val w = r - l
                                            val h = b - t
                                            val nl = (l + dx).coerceIn(0f, 1f - w)
                                            val nt = (t + dy).coerceIn(0f, 1f - h)
                                            l = nl; r = nl + w; t = nt; b = nt + h
                                        }
                                    }
                                }
                            )
                        }
                    ) {
                        val rl = ox + l * dw
                        val rt = oy + t * dh
                        val rr = ox + r * dw
                        val rb = oy + b * dh
                        val dim = Color.Black.copy(alpha = 0.55f)
                        drawRect(dim, Offset(0f, 0f), Size(size.width, rt))
                        drawRect(dim, Offset(0f, rb), Size(size.width, size.height - rb))
                        drawRect(dim, Offset(0f, rt), Size(rl, rb - rt))
                        drawRect(dim, Offset(rr, rt), Size(size.width - rr, rb - rt))
                        val blue = Color(0xFF2BA8FF)
                        drawRect(blue, Offset(rl, rt), Size(rr - rl, rb - rt), style = Stroke(3.dp.toPx()))
                        for ((cx, cy) in listOf(rl to rt, rr to rt, rl to rb, rr to rb)) {
                            drawCircle(blue, 10.dp.toPx(), Offset(cx, cy))
                        }
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onCancel) { Text("إلغاء") }
                    OutlinedButton(onClick = onFull) { Text("استخدم الكل") }
                    Button(onClick = { onConfirm(l, t, r, b) }, modifier = Modifier.weight(1f)) { Text("قص وإرسال") }
                }
            }
        }
    }
}
