package com.ichat.offline.ui

import android.graphics.BitmapFactory
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import kotlinx.coroutines.delay
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.graphicsLayer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ichat.offline.ChatViewModel
import com.ichat.offline.data.MessageEntity
import kotlinx.coroutines.launch

/** لما يكون true بنوقف الحركات المستمرة (عشان ما تبطّأش الرد أثناء التفكير) */
val LocalCalm = compositionLocalOf { false }

@Composable
fun Mascot(dp: Dp, thinking: Boolean = false) {
    val animated = !LocalCalm.current
    val t = rememberInfiniteTransition(label = "mascot")
    val bob = if (animated) t.animateFloat(
        initialValue = -1f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(if (thinking) 600 else 1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bob"
    ).value else 0f
    val blink = if (animated) t.animateFloat(
        initialValue = 1f, targetValue = 1f,
        animationSpec = infiniteRepeatable(keyframes {
            durationMillis = 3600
            1f at 0
            1f at 3300
            0.1f at 3420
            1f at 3540
        }),
        label = "blink"
    ).value else 1f
    val pulse = if (animated) t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(500), RepeatMode.Reverse),
        label = "pulse"
    ).value else 0f
    val amp = dp.value * 0.04f
    Canvas(Modifier.size(dp).offset(y = (bob * amp).dp)) {
        val w = this.size.width
        val blue = Color(0xFF2BA8FF)
        drawCircle(Color(0xFFE8F1FF), radius = w * 0.42f, center = Offset(w / 2, w / 2))
        drawRoundRect(
            Color(0xFF0B1530), topLeft = Offset(w * 0.2f, w * 0.34f),
            size = Size(w * 0.6f, w * 0.3f), cornerRadius = CornerRadius(w * 0.12f)
        )
        val st = Stroke(width = w * 0.035f, cap = StrokeCap.Round)
        val eyeH = w * 0.12f * blink
        val eyeY = w * 0.43f + (w * 0.12f - eyeH) / 2f
        drawArc(blue, 200f, 140f, false, Offset(w * 0.3f, eyeY), Size(w * 0.15f, eyeH), style = st)
        drawArc(blue, 200f, 140f, false, Offset(w * 0.55f, eyeY), Size(w * 0.15f, eyeH), style = st)
        val ear = w * 0.04f * (1f + (if (thinking) 0.7f * pulse else 0f))
        drawCircle(blue, radius = ear, center = Offset(w * 0.07f, w * 0.5f))
        drawCircle(blue, radius = ear, center = Offset(w * 0.93f, w * 0.5f))
    }
}

@Composable
private fun ThinkingRow(label: String) {
    val animated = !LocalCalm.current
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 6.dp)) {
        if (animated) {
            val t = rememberInfiniteTransition(label = "think")
            val alpha by t.animateFloat(
                initialValue = 0.45f, targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "labelAlpha"
            )
            for (i in 0..2) {
                val a by t.animateFloat(
                    initialValue = 0.25f, targetValue = 1f,
                    animationSpec = infiniteRepeatable(tween(600, delayMillis = i * 200), RepeatMode.Reverse),
                    label = "dot$i"
                )
                Box(Modifier.padding(end = 5.dp).size(9.dp).graphicsLayer { this.alpha = a }.background(MaterialTheme.colorScheme.primary, CircleShape))
            }
            Spacer(Modifier.width(6.dp))
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.graphicsLayer { this.alpha = alpha })
        } else {
            Text("●●●", color = MaterialTheme.colorScheme.primary, fontSize = 10.sp)
            Spacer(Modifier.width(8.dp))
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun OfflineBadge() {
    Surface(color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f), shape = RoundedCornerShape(8.dp)) {
        Text("Offline", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 1.dp))
    }
}

@Composable
fun ChatScreen(vm: ChatViewModel, onSettings: () -> Unit, onModel: () -> Unit) {
    val ctx = LocalContext.current
    val generating by vm.generating.collectAsStateWithLifecycle()
    val animPref = remember { ctx.getSharedPreferences("settings", 0).getBoolean("anim_think", false) }
    CompositionLocalProvider(LocalCalm provides (generating && !animPref)) { ChatScreenBody(vm, onSettings, onModel) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChatScreenBody(vm: ChatViewModel, onSettings: () -> Unit, onModel: () -> Unit) {
    val ctx = LocalContext.current
    val messages by vm.messages.collectAsStateWithLifecycle()
    val chats by vm.chats.collectAsStateWithLifecycle()
    val currentId by vm.currentId.collectAsStateWithLifecycle()
    val stream by vm.stream.collectAsStateWithLifecycle()
    val generating by vm.generating.collectAsStateWithLifecycle()
    val speed by vm.speed.collectAsStateWithLifecycle()
    val pending by vm.pendingImage.collectAsStateWithLifecycle()
    val notice by vm.notice.collectAsStateWithLifecycle()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.attachImage(uri)
    }
    var input by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    val haptic = LocalHapticFeedback.current
    val pulseT = rememberInfiniteTransition(label = "send")
    val calmNow = LocalCalm.current
    val sendPulse = if (generating && !calmNow) pulseT.animateFloat(
        initialValue = 1f, targetValue = 1.1f,
        animationSpec = infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "sendPulse"
    ).value else 1f
    var dialog by remember { mutableStateOf<String?>(null) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1) }
    val streamLen = stream?.text?.length ?: 0
    LaunchedEffect(streamLen) { if (streamLen > 0) listState.scrollBy(10000f) }
    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }
    val close: () -> Unit = { scope.launch { drawerState.close() } }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                LazyColumn(contentPadding = PaddingValues(12.dp)) {
                    item {
                        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Mascot(44.dp)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("iChat", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                                OfflineBadge()
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                    item { NavigationDrawerItem(label = { Text("محادثة جديدة") }, icon = { Text("💬") }, selected = false,
                        onClick = { vm.newChat(); close() }) }
                    item { NavigationDrawerItem(label = { Text("تحميل نموذج الذكاء الاصطناعي") }, icon = { Text("⬇️") }, selected = false,
                        onClick = { close(); onModel() }) }
                    item { NavigationDrawerItem(label = { Text("إعدادات التطبيق") }, icon = { Text("⚙️") }, selected = false,
                        onClick = { close(); onSettings() }) }
                    item { NavigationDrawerItem(label = { Text("مشاركة المحادثة") }, icon = { Text("📤") }, selected = false,
                        onClick = { close(); vm.shareChat(ctx) }) }
                    item { NavigationDrawerItem(label = { Text("عن التطبيق") }, icon = { Text("ℹ️") }, selected = false,
                        onClick = { dialog = "about"; close() }) }
                    item { NavigationDrawerItem(label = { Text("مساعدة") }, icon = { Text("❓") }, selected = false,
                        onClick = { dialog = "help"; close() }) }
                    if (chats.isNotEmpty()) {
                        item {
                            HorizontalDivider(Modifier.padding(vertical = 8.dp))
                            Text("المحادثات السابقة", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(8.dp))
                        }
                        items(chats, key = { it.id }) { c ->
                            NavigationDrawerItem(
                                label = { Text(c.title, maxLines = 1) }, selected = c.id == currentId,
                                onClick = { vm.open(c.id); close() },
                                badge = { IconButton(onClick = { vm.deleteChat(c.id) }) { Icon(Icons.Default.Delete, "حذف") } }
                            )
                        }
                    }
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Mascot(26.dp, thinking = generating)
                                Spacer(Modifier.width(6.dp))
                                Text("iChat", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                OfflineBadge()
                                speed?.let {
                                    Spacer(Modifier.width(6.dp))
                                    Text(it, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                    navigationIcon = { IconButton(onClick = { scope.launch { drawerState.open() } }) { Icon(Icons.Default.Menu, "القائمة") } },
                    actions = { IconButton(onClick = { vm.newChat() }) { Icon(Icons.Default.Add, "محادثة جديدة") } }
                )
            },
            bottomBar = {
                Column(Modifier.fillMaxWidth().navigationBarsPadding().imePadding()) {
                pending?.let { p ->
                    Row(Modifier.padding(start = 10.dp, end = 10.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        PhotoView(p, Modifier.size(64.dp))
                        TextButton(onClick = { vm.clearPending() }) { Text("✕ إزالة الصورة") }
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(10.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    IconButton(
                        onClick = { if (vm.canAttach()) picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        enabled = !generating
                    ) { Text("📎", fontSize = 24.sp) }
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f).focusRequester(focus), placeholder = { Text("اكتب سؤالك هنا...") },
                        maxLines = 5, shape = RoundedCornerShape(26.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    )
                    Spacer(Modifier.width(8.dp))
                    FilledIconButton(
                        onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); if (generating) vm.stop() else { vm.send(input); input = "" } },
                        enabled = generating || input.isNotBlank() || pending != null,
                        modifier = Modifier.size(52.dp).graphicsLayer { val s = if (generating) sendPulse else 1f; scaleX = s; scaleY = s }
                    ) { if (generating) Text("■", fontSize = 20.sp) else Icon(Icons.AutoMirrored.Filled.Send, "إرسال") }
                }
                }
            }
        ) { pad ->
            if (messages.isEmpty()) {
                Column(
                    Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                ) {
                    Mascot(110.dp)
                    Spacer(Modifier.height(8.dp))
                    Text("أهلاً 👋", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Text("إزاي أقدر أساعدك النهارده؟", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(20.dp))
                    val cards = listOf(
                        Triple("📸", "حلّ صورة امتحان", "صوّر السؤال وأنا أحله"),
                        Triple("💻", "اكتب كود", "بايثون، ويب، وغيرهم"),
                        Triple("📚", "اشرح لي درس", "بشكل بسيط وخطوة بخطوة"),
                        Triple("✍️", "لخّص أو صحّح", "لخّص نص أو راجع كتابتك")
                    )
                    cards.chunked(2).forEachIndexed { r, pair ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            pair.forEachIndexed { c, (emoji, title, sub) ->
                                var cardShown by remember { mutableStateOf(false) }
                                LaunchedEffect(Unit) { delay((r * 2 + c) * 110L); cardShown = true }
                                AnimatedVisibility(
                                    visible = cardShown, modifier = Modifier.weight(1f),
                                    enter = fadeIn(tween(350)) + slideInVertically(tween(350), { it / 4 })
                                ) {
                                Surface(
                                    onClick = {
                                        if (title == "حلّ صورة امتحان") {
                                            if (vm.canAttach()) picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                        } else {
                                            input = when (title) {
                                                "اكتب كود" -> "اكتب لي كود "
                                                "اشرح لي درس" -> "اشرح لي درس "
                                                else -> "لخّص لي النص ده: "
                                            }
                                            focus.requestFocus()
                                        }
                                    },
                                    shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                                ) {
                                    Column(Modifier.padding(16.dp)) {
                                        Text(emoji, fontSize = 28.sp)
                                        Spacer(Modifier.height(6.dp))
                                        Text(title, fontWeight = FontWeight.Bold)
                                        Text(sub, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                }
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    Modifier.padding(pad).fillMaxSize(), state = listState,
                    contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    itemsIndexed(messages, key = { _, m -> m.id }) { i, m ->
                        MessageBubble(
                            m, stream?.takeIf { it.id == m.id }?.text,
                            isLast = i == messages.lastIndex && !generating,
                            onRegenerate = { vm.regenerate() },
                            onFollowUp = { vm.send(it) }
                        )
                    }
                }
            }
        }
    }

    val cropPath by vm.cropSource.collectAsStateWithLifecycle()
    cropPath?.let { p ->
        CropDialog(
            path = p,
            onConfirm = { l, t, r, b -> vm.cropConfirm(l, t, r, b) },
            onFull = { vm.cropFull() },
            onCancel = { vm.cropCancel() }
        )
    }

    notice?.let { n ->
        AlertDialog(
            onDismissRequest = { vm.clearNotice() }, title = { Text("تنبيه") }, text = { Text(n) },
            confirmButton = { TextButton(onClick = { vm.clearNotice() }) { Text("تمام") } }
        )
    }

    dialog?.let { key ->
        val (t, body) = when (key) {
            "about" -> "عن iChat" to "الإصدار 0.8: واجهة المحادثة، وحفظ السجل، وتشغيل نماذج Qwen محليًا بعد تنزيلها، وفهم الصور مع نموذج Qwen3-VL-8B. فهم الصور لسه مش موجود (المرحلة 3)."
            else -> "مساعدة" to "أول مرة: افتح القائمة واختار «تحميل نموذج الذكاء الاصطناعي» ونزّل النموذج. بعدها اكتب سؤالك. كل المحادثات محفوظة على موبايلك بس."
        }
        AlertDialog(
            onDismissRequest = { dialog = null }, title = { Text(t) }, text = { Text(body) },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("تمام") } }
        )
    }
}

@Composable
private fun PhotoView(path: String, modifier: Modifier) {
    val bmp = remember(path) { BitmapFactory.decodeFile(path)?.asImageBitmap() }
    if (bmp != null) Image(bmp, null, modifier.clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Fit)
}

@Composable
private fun MessageBubble(m: MessageEntity, streamText: String?, isLast: Boolean, onRegenerate: () -> Unit, onFollowUp: (String) -> Unit) {
    var shown by rememberSaveable(m.id) { mutableStateOf(false) }
    LaunchedEffect(m.id) { shown = true }
    AnimatedVisibility(
        visible = shown,
        enter = fadeIn(tween(300)) + slideInVertically(tween(300), { it / 5 })
    ) { MessageBubbleContent(m, streamText, isLast, onRegenerate, onFollowUp) }
}

@Composable
private fun MessageBubbleContent(m: MessageEntity, streamText: String?, isLast: Boolean, onRegenerate: () -> Unit, onFollowUp: (String) -> Unit) {
    val clipboard = LocalClipboardManager.current
    val cs = MaterialTheme.colorScheme
    when (m.role) {
        "user" -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
            Surface(color = cs.primaryContainer, shape = RoundedCornerShape(18.dp), modifier = Modifier.widthIn(max = 300.dp)) {
                Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                    m.imagePath?.let { PhotoView(it, Modifier.widthIn(max = 240.dp).padding(bottom = 6.dp)) }
                    Text(m.content, color = cs.onPrimaryContainer)
                }
            }
        }
        "system" -> Surface(color = cs.surfaceVariant, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text(m.content, color = cs.onSurfaceVariant, fontSize = 14.sp)
                if (isLast) TextButton(onClick = onRegenerate) { Text("إعادة المحاولة") }
            }
        }
        else -> Surface(
            color = cs.surfaceVariant, shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, cs.outlineVariant), modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(12.dp)) {
                val shownText = streamText ?: m.content
                if (shownText == "…" || shownText.startsWith("استني")) {
                    ThinkingRow(if (shownText == "…") "استني بفكر" else shownText)
                } else if (streamText != null) {
                    Text(shownText + " ▍")
                } else Markdown(shownText)
                if (streamText == null) Row {
                    TextButton(onClick = { clipboard.setText(AnnotatedString(m.content)) }) { Text("نسخ") }
                    if (isLast) TextButton(onClick = onRegenerate) { Text("إعادة") }
                }
                if (streamText == null && isLast) Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                    listOf("اشرح أكتر" to "اشرح أكتر", "بسّطها" to "بسّط الشرح أكتر", "مثال" to "اديني مثال").forEach { (label, q) ->
                        Surface(
                            onClick = { onFollowUp(q) }, shape = RoundedCornerShape(50),
                            color = cs.primaryContainer.copy(alpha = 0.55f)
                        ) { Text(label, Modifier.padding(horizontal = 12.dp, vertical = 6.dp), fontSize = 13.sp, color = cs.onPrimaryContainer) }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    themeMode: String, onTheme: (String) -> Unit, prompt: String, onPrompt: (String) -> Unit,
    defaultPrompt: String, threads: Int, onThreads: (Int) -> Unit, imgSide: Int, onImgSide: (Int) -> Unit,
    webSearch: Boolean, onWebSearch: (Boolean) -> Unit,
    batterySaver: Boolean, onBatterySaver: (Boolean) -> Unit,
    animThink: Boolean, onAnimThink: (Boolean) -> Unit,
    onDeleteAll: () -> Unit, onBack: () -> Unit
) {
    var confirm by remember { mutableStateOf(false) }
    var askWeb by remember { mutableStateOf(false) }
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("الإعدادات") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") } }
        )
    }) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("المظهر", style = MaterialTheme.typography.titleMedium)
            listOf("system" to "حسب النظام", "light" to "فاتح", "dark" to "داكن").forEach { (k, label) ->
                Row(
                    Modifier.fillMaxWidth().clickable { onTheme(k) },
                    verticalAlignment = Alignment.CenterVertically
                ) { RadioButton(selected = themeMode == k, onClick = { onTheme(k) }); Text(label) }
            }
            HorizontalDivider()
            Text("الخصوصية", style = MaterialTheme.typography.titleMedium)
            Text("كل المحادثات تُحفظ على هاتفك فقط، ولا يرسل التطبيق أي شيء لأي خادم. الإنترنت سيُستخدم لاحقًا فقط لتنزيل النموذج بموافقتك.")
            HorizontalDivider()
            Text("عدد أنوية المعالج", style = MaterialTheme.typography.titleMedium)
            Text("جرّب أرقام مختلفة: الأقل بيسخّن أقل، والأكتر ممكن يكون أسرع أو أبطأ حسب جهازك. التغيير بيتطبّق من الرسالة الجاية. المقترح حسب جهازك: ${Runtime.getRuntime().availableProcessors().coerceIn(3, 8)}", fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(3, 4, 6, 8).forEach { n ->
                    FilterChip(selected = threads == n, onClick = { onThreads(n) }, label = { Text("$n") })
                }
            }
            HorizontalDivider()
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("وضع توفير البطارية", style = MaterialTheme.typography.titleMedium)
                    Text("يقلل عدد الأنوية لأقصى 3 ويقلل طول الرد. أبطأ شوية بس أوفر للبطارية وأقل سخونة.", fontSize = 14.sp)
                }
                Switch(checked = batterySaver, onCheckedChange = onBatterySaver)
            }
            HorizontalDivider()
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("البحث على الإنترنت (ويكيبيديا)", style = MaterialTheme.typography.titleMedium)
                    Text("لما تكون متصل، التطبيق بيدوّر على سؤالك في ويكيبيديا ويدّي النموذج المعلومات عشان إجاباته تبقى أدق. مقفول افتراضيًا، ومش بيشتغل مع الصور.", fontSize = 14.sp)
                }
                Switch(checked = webSearch, onCheckedChange = { if (it) askWeb = true else onWebSearch(false) })
            }
            HorizontalDivider()
            Text("جودة الصور (أكبر تأثير على السرعة)", style = MaterialTheme.typography.titleMedium)
            Text("سريعة = أسرع بكتير في أول رد. عالية = أوضح للخط الصغير بس ممكن تستنى أكتر. الافتراضي: سريعة.", fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(640 to "سريعة ⚡", 896 to "متوسطة", 1024 to "عالية").forEach { (px, label) ->
                    FilterChip(selected = imgSide == px, onClick = { onImgSide(px) }, label = { Text(label) })
                }
            }
            HorizontalDivider()
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("حركات أثناء التفكير", style = MaterialTheme.typography.titleMedium)
                    Text("تشغيلها بيخلّي الشكل أحلى لكن ممكن يبطّأ الرد كتير. الأفضل تسيبها مقفولة.", fontSize = 14.sp)
                }
                Switch(checked = animThink, onCheckedChange = onAnimThink)
            }
            HorizontalDivider()
            Text("تعليمات النموذج (متقدم)", style = MaterialTheme.typography.titleMedium)
            Text("ده الكلام اللي بيتبعت للنموذج قبل كل محادثة. تقدر تعدّله (مثلًا تطلب منه يرد بالعامية لو النموذج قوي) وتجرّب من غير ما تحتاج تحديث للتطبيق.", fontSize = 14.sp)
            OutlinedTextField(value = prompt, onValueChange = onPrompt, minLines = 4, maxLines = 12, modifier = Modifier.fillMaxWidth())
            OutlinedButton(onClick = { onPrompt(defaultPrompt) }) { Text("استعادة الافتراضي") }
            HorizontalDivider()
            OutlinedButton(onClick = { confirm = true }) { Text("حذف كل المحادثات") }
        }
    }
    if (askWeb) AlertDialog(
        onDismissRequest = { askWeb = false },
        title = { Text("تفعيل البحث على الإنترنت؟") },
        text = { Text("هيتبعت نص سؤالك بس لخادم ويكيبيديا (wikipedia.org) عشان يدوّر عليه. محادثاتك وصورك فاضلة على موبايلك. لو الإنترنت مش موجود، التطبيق هيشتغل عادي من غير بحث. موافق؟") },
        confirmButton = { TextButton(onClick = { onWebSearch(true); askWeb = false }) { Text("موافق") } },
        dismissButton = { TextButton(onClick = { askWeb = false }) { Text("إلغاء") } }
    )
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("حذف كل المحادثات؟") },
        text = { Text("لا يمكن التراجع عن هذا الإجراء.") },
        confirmButton = { TextButton(onClick = { onDeleteAll(); confirm = false }) { Text("حذف") } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("إلغاء") } }
    )
}
